package group1.nutty;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import group1.nutty.adapter.BasicSearchListAdapter;
import group1.nutty.adapter.NewsFeedAdapter;
import group1.nutty.model.Recipe;

public class ProfileActivity extends Activity {

    static ListView userRecipes;
    static ListView sharedRecipes;
    static  ArrayList<Recipe> userRecipesArray = new ArrayList<Recipe>();
    static  ArrayList<Recipe> sharedRecipesArray = new ArrayList<Recipe>();
    static ArrayAdapter<Recipe> userRecipeAdapter;
    static ArrayAdapter<Recipe> sharedRecipeAdapter;

    TextView following;
    TextView followers;

    ArrayList<Integer> followersArr = new ArrayList<Integer>();
    ArrayList<Integer> followingArr = new ArrayList<Integer>();
    static ArrayList<JSONObject> news = new ArrayList<JSONObject>();
    static ListView newsFeeds;
    static ArrayAdapter<JSONObject> newsFeedAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        final MyApplication myApplication = (MyApplication) getApplicationContext();
        final TextView nameSurname = (TextView) findViewById(R.id.nameSurname);
        nameSurname.setText(myApplication.getUser().getName() + " " + myApplication.getUser().getSurname());

        TabHost tabhost = (TabHost) findViewById(R.id.tabHost);
        tabhost.setup();

        TabSpec ts = tabhost.newTabSpec("tag1");
        ts.setContent(R.id.recipes);
        ts.setIndicator("Recipes");
        tabhost.addTab(ts);

        userRecipes = (ListView) findViewById(R.id.userRecipes);
        GetUserRecipesTask getUserRecipesTask = new GetUserRecipesTask(MyApplication.getUser().getId());
        getUserRecipesTask.execute();

        ts = tabhost.newTabSpec("tag2");
        ts.setContent(R.id.favorites);
        ts.setIndicator("Shared");
        tabhost.addTab(ts);

        sharedRecipes = (ListView) findViewById(R.id.sharedRecipes);
        GetSharedRecipesTask getSharedRecipesTask = new GetSharedRecipesTask(MyApplication.getUser().getId());
        getSharedRecipesTask.execute();

        ts= tabhost.newTabSpec("tag3");
        ts.setContent(R.id.rates);
        ts.setIndicator("Activities");
        tabhost.addTab(ts);

        newsFeeds = (ListView) findViewById(R.id.activities);
        GetRecentActivities getRecentActivities = new GetRecentActivities(MyApplication.getUser().getId(), getApplicationContext());
        getRecentActivities.execute();

        followers = (TextView) findViewById(R.id.followers);
        following = (TextView) findViewById(R.id.following);

        GetFollowers getFollowers = new GetFollowers(MyApplication.getUser().getId());
        getFollowers.execute();

        GetFollowing getFollowing = new GetFollowing(MyApplication.getUser().getId());
        getFollowing.execute();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            Intent allSetting = new Intent(getApplicationContext(), AllSettings.class);
            startActivity(allSetting);
            return true;
        }
        else if(id == R.id.action_logout){
            MyApplication myApplication = (MyApplication) getApplicationContext();
            myApplication.reset();
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            return true;
        }else if(id == R.id.action_profile){
            Intent intent = new Intent(this, ProfileActivity.class);
            startActivity(intent);
            return true;
        }
        else if(id == R.id.search){
            Intent intent = new Intent(this, SearchActivity.class);
            startActivity(intent);
            return true;
        }else if(id == R.id.home){
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    public void openSettings(View view) {
        Intent intent = new Intent(this, AllSettings.class);
        startActivity(intent);
    }
    public void addRecipe(View view) {
        Intent intent = new Intent(getApplicationContext(),AddRecipeActivity.class);
        startActivity(intent);
//        GetIngredients task = new GetIngredients();
//        task.execute((Void) null);
    }

    public class GetUserRecipesTask extends AsyncTask<Void, Void, String> {

        long userID;

        InputStream is = null ;
        String result = "";

        GetUserRecipesTask(long userID) {
            this.userID = userID;

        }
        @Override
        public void onPreExecute(){
            userRecipesArray = new ArrayList<Recipe>();
        }

        @Override
        protected String doInBackground(Void... params) {

            HttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost("http://titan.cmpe.boun.edu.tr:8080/nutty/user/getUsersRecipes?userId="+userID);
            try {
                HttpResponse httpResponse = httpClient.execute(httpPost);
                HttpEntity httpEntity = httpResponse.getEntity();
                //read content
                is =  httpEntity.getContent();
                Thread.sleep(2000);
            }catch (Exception e) {
                Log.e("log_tag", "Error in http connection " + e.toString());
                return e.toString();
            }
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                StringBuilder sb = new StringBuilder();
                String line = "";
                while((line=br.readLine())!=null){
                    sb.append(line+"\n");
                }
                is.close();
                result=sb.toString();
            }catch (Exception e) {
                Log.e("log_tag", "Error converting result " + e.toString());
            }
            return result;
        }

        @Override
        protected void onPostExecute(final String result) {
            System.out.println(result);
            try {
                Gson gson = new Gson();
                String[][] recipes = gson.fromJson(result, String[][].class);
                for(String[] recipe : recipes){
                    Recipe newRecipe = new Recipe();
                    newRecipe.setRecipe_id(Integer.parseInt(recipe[0]));
                    MyApplication.getUser().addOwnedRecipeID(Integer.parseInt(recipe[0]));
                    newRecipe.setName(recipe[1]);
                    newRecipe.setPhoto(recipe[2]);//This is for photo URL
                    userRecipesArray.add(newRecipe);
                }
                userRecipeAdapter = new BasicSearchListAdapter(getApplicationContext(), userRecipesArray);
                userRecipes.setAdapter(userRecipeAdapter);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public class GetSharedRecipesTask extends AsyncTask<Void, Void, String> {

        long userID;

        InputStream is = null ;
        String result = "";

        GetSharedRecipesTask(long userID) {
            this.userID = userID;

        }
        @Override
        public void onPreExecute(){
            sharedRecipesArray = new ArrayList<Recipe>();
        }

        @Override
        protected String doInBackground(Void... params) {

            HttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost("http://titan.cmpe.boun.edu.tr:8080/nutty/user/getSharedRecipes?userId="+userID);
            try {
                HttpResponse httpResponse = httpClient.execute(httpPost);
                HttpEntity httpEntity = httpResponse.getEntity();
                //read content
                is =  httpEntity.getContent();
                Thread.sleep(2000);
            }catch (Exception e) {
                Log.e("log_tag", "Error in http connection " + e.toString());
                return e.toString();
            }
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                StringBuilder sb = new StringBuilder();
                String line = "";
                while((line=br.readLine())!=null){
                    sb.append(line+"\n");
                }
                is.close();
                result=sb.toString();
            }catch (Exception e) {
                Log.e("log_tag", "Error converting result " + e.toString());
            }
            return result;
        }

        @Override
        protected void onPostExecute(final String result) {
            System.out.println(result);
            try {
                Gson gson = new Gson();
                String[][] recipes = gson.fromJson(result, String[][].class);
                for(String[] recipe : recipes){
                    Recipe newRecipe = new Recipe();
                    newRecipe.setRecipe_id(Integer.parseInt(recipe[0]));
                    newRecipe.setName(recipe[1]);
                    newRecipe.setPhoto(recipe[2]);//This is for photo URL
                    sharedRecipesArray.add(newRecipe);
                }
                sharedRecipeAdapter = new BasicSearchListAdapter(getApplicationContext(), sharedRecipesArray);
                sharedRecipes.setAdapter(sharedRecipeAdapter);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public class GetFollowers extends AsyncTask<Void, Void, String> {

        long userID;

        InputStream is = null ;
        String result = "";

        GetFollowers(long userID) {
            this.userID = userID;

        }
        @Override
        protected void onPreExecute(){
            followersArr = new ArrayList<Integer>();
        }
        @Override
        protected String doInBackground(Void... params) {

            HttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost("http://titan.cmpe.boun.edu.tr:8080/nutty/user/getFollowerListREST?user_id="+userID);
            try {
                HttpResponse httpResponse = httpClient.execute(httpPost);
                HttpEntity httpEntity = httpResponse.getEntity();
                //read content
                is =  httpEntity.getContent();
                Thread.sleep(2000);
            }catch (Exception e) {
                Log.e("log_tag", "Error in http connection " + e.toString());
                return e.toString();
            }
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                StringBuilder sb = new StringBuilder();
                String line = "";
                while((line=br.readLine())!=null){
                    sb.append(line+"\n");
                }
                is.close();
                result=sb.toString();
            }catch (Exception e) {
                Log.e("log_tag", "Error converting result " + e.toString());
            }
            return result;
        }

        @Override
        protected void onPostExecute(final String result) {
            System.out.println(result);

            try {
                JSONArray jsonArray = new JSONArray(result);
                for(int i = 0; i<jsonArray.length(); i++){
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    followersArr.add(jsonObject.getInt("id"));
                }
                followers.setText("Followers: "+jsonArray.length());
            } catch (JSONException e) {
                e.printStackTrace();
                followers.setText("Followers: 0");
            }
        }
    }

    public class GetFollowing extends AsyncTask<Void, Void, String> {

        long userID;

        InputStream is = null ;
        String result = "";

        GetFollowing(long userID) {
            this.userID = userID;

        }
        @Override
        protected void onPreExecute(){
            followersArr = new ArrayList<Integer>();
        }
        @Override
        protected String doInBackground(Void... params) {

            HttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost("http://titan.cmpe.boun.edu.tr:8080/nutty/user/getFollowingListREST?user_id="+userID);
            try {
                HttpResponse httpResponse = httpClient.execute(httpPost);
                HttpEntity httpEntity = httpResponse.getEntity();
                //read content
                is =  httpEntity.getContent();
                Thread.sleep(2000);
            }catch (Exception e) {
                Log.e("log_tag", "Error in http connection " + e.toString());
                return e.toString();
            }
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                StringBuilder sb = new StringBuilder();
                String line = "";
                while((line=br.readLine())!=null){
                    sb.append(line+"\n");
                }
                is.close();
                result=sb.toString();
            }catch (Exception e) {
                Log.e("log_tag", "Error converting result " + e.toString());
            }
            return result;
        }

        @Override
        protected void onPostExecute(final String result) {
            System.out.println(result);

            try {
                JSONArray jsonArray = new JSONArray(result);
                for(int i = 0; i<jsonArray.length(); i++){
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    followingArr.add(jsonObject.getInt("id"));
                }
                following.setText("Followers: "+jsonArray.length());
            } catch (JSONException e) {
                e.printStackTrace();
                following.setText("Followers: 0");
            }
        }
    }
    public static class GetRecentActivities extends AsyncTask<Void, Void, String> {

        int userID;

        InputStream is = null ;
        String result = "";
        Context context;

        public GetRecentActivities(int userID, Context context) {
            this.userID = userID;
            this.context = context;
        }

        @Override
        public void onPreExecute(){
            news = new ArrayList<JSONObject>();
        }

        @Override
        protected String doInBackground(Void... params) {

            HttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost("http://titan.cmpe.boun.edu.tr:8080/nutty/user/getUsersRecentEvents?user_id="+userID);
            try {
                HttpResponse httpResponse = httpClient.execute(httpPost);
                HttpEntity httpEntity = httpResponse.getEntity();
                //read content
                is =  httpEntity.getContent();
                Thread.sleep(2000);
            }catch (Exception e) {
                Log.e("log_tag", "Error in http connection " + e.toString());
                return e.toString();
            }
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                StringBuilder sb = new StringBuilder();
                String line = "";
                while((line=br.readLine())!=null){
                    sb.append(line+"\n");
                }
                is.close();
                result=sb.toString();
            }catch (Exception e) {
                Log.e("log_tag", "Error converting result " + e.toString());
            }
            return result;
        }

        @Override
        protected void onPostExecute(final String result) {
            System.out.println(result);
            try {
                JSONArray jsonArray = new JSONArray(result);
                for(int i=0; i<jsonArray.length(); i++){
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    news.add(jsonObject);
                    System.out.println(jsonObject.getString("timestamp"));
                }
                newsFeedAdapter = new NewsFeedAdapter(context, news);
                newsFeeds.setAdapter(newsFeedAdapter);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
