package group1.nutty;

import android.app.Application;

import group1.nutty.model.User;

/**
 * Created by gokhanonalan on 06/11/14.
 */
public class MyApplication extends Application {
    private static User user;

    public static User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void reset(){
        this.user = null;
    }
}
