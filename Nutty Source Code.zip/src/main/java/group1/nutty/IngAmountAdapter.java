package group1.nutty;

import android.content.Context;
import android.os.AsyncTask;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import group1.nutty.model.Comment;
import group1.nutty.model.IngredientAmount;

/**
 * Created by gokhanonalan on 07/12/14.
 */
public class IngAmountAdapter extends ArrayAdapter<IngredientAmount> {
    private ArrayList<IngredientAmount> ingredients;
    private Context context;
    private IngAmountAdapter self;

    ArrayList<Integer> ingIDs = new ArrayList<Integer>();
    ArrayList<String> ingNames = new ArrayList<String>();
    ArrayAdapter<String> adapter;

    ViewHolder holder;

//    private AutoCompleteTextView ingredientName;

    public IngAmountAdapter(Context context, ArrayList<IngredientAmount> ingredients) {
        super(context,R.layout.ing_amount_layout, ingredients);
        this.context = context;
        this.ingredients=ingredients;
        self=this;
    }

    private static class ViewHolder {
        private AutoCompleteTextView ingName;
        private EditText ingAmount;
        private Button removeIngredient;
    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        View view = null;

        if (convertView == null) {
            LayoutInflater inflator = LayoutInflater.from(this.getContext());
            view = inflator.inflate(R.layout.ing_amount_layout, null);
            final ViewHolder viewHolder = new ViewHolder();
            viewHolder.ingName = (AutoCompleteTextView) view.findViewById(R.id.ingName);
            viewHolder.ingAmount = (EditText) view.findViewById(R.id.ingAmount);
            viewHolder.removeIngredient = (Button) view.findViewById(R.id.removeIng);
            view.setTag(viewHolder);
        } else {
            view = convertView;
        }
        holder = (ViewHolder) view.getTag();
        holder.removeIngredient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ingredients.remove(position);
                self.notifyDataSetChanged();
            }
        });

//        ingredientName = holder.ingName;
        holder.ingName.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable s) {
                String ingName = holder.ingName.getText().toString();
                if (ingName.length() == 4) {
                    System.out.println(ingName);
                    GetIngredients getIngredients = new GetIngredients(ingName, holder.ingName);
                    getIngredients.execute();
                } else {

                }
            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
        });

        return view;

    }
    public class GetIngredients extends AsyncTask<Void, Void, String> {
        InputStream is = null ;
        String result = "";

        String ingName;
        AutoCompleteTextView textView;

        GetIngredients(String ingName, AutoCompleteTextView textView) {
            this.ingName = ingName;
            this.textView = textView;
        }

        @Override
        protected void onPreExecute(){
            ingIDs = new ArrayList<Integer>();
            ingNames = new ArrayList<String>();
        }

        @Override
        protected String doInBackground(Void... params) {

            HttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost("http://titan.cmpe.boun.edu.tr:8080/nutty/someIngredients2?filter="+ingName);
            try {
                HttpResponse httpResponse = httpClient.execute(httpPost);
                HttpEntity httpEntity = httpResponse.getEntity();
                //read content
                is =  httpEntity.getContent();
                Thread.sleep(2000);
            }catch (Exception e) {
                Log.e("log_tag", "Error in http connection " + e.toString());
//                return e.toString();
                return null;
            }
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                StringBuilder sb = new StringBuilder();
                String line = "";
                while((line=br.readLine())!=null){
                    sb.append(line+"\n");
                }
                is.close();
                result=sb.toString();
            }catch (Exception e) {
                Log.e("log_tag", "Error converting result " + e.toString());
            }
            return result;
        }

        @Override
        protected void onPostExecute(final String result) {
            try {
                JSONArray jsonArray = new JSONArray(result);
                String[] temp = new String[jsonArray.length()];
                for(int i=0; i<jsonArray.length(); i++){
                    JSONObject object = (JSONObject) jsonArray.get(i);
                    temp[i] = object.getString("ing_name");
                }
//                while (keys.hasNext()) {
//                    String key = (String) keys.next();
//                    ingIDs.add(Integer.parseInt(key));
//                    ingNames.add(jsonObject.getString(key));
//                }
                System.out.println(temp);
                adapter = new ArrayAdapter<String>(
                        context, android.R.layout.select_dialog_item, temp);
                holder.ingName.setThreshold(1);
                holder.ingName.setAdapter(adapter);

                adapter.notifyDataSetChanged();
                System.out.println(adapter.getCount());
                System.out.println(holder.ingName.getAdapter().getCount());

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        @Override
        protected void onCancelled() {
        }
    }
}
