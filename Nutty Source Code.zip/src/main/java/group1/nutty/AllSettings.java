package group1.nutty;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class AllSettings extends Activity {

    private ListView settings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_settings);

        settings = (ListView) findViewById(R.id.settings);
        List<String> allSettings = new ArrayList<String>();
        allSettings.add("User Settings");
        allSettings.add("Food Preferences");
        allSettings.add("Following Requests");
        allSettings.add("Privacy Settings");

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(
                this,
                android.R.layout.simple_list_item_1,
                allSettings);

        settings.setAdapter(arrayAdapter);

        settings.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> av, View view, int i, long l) {
//                Toast.makeText(getApplicationContext(), "myPos " + i, Toast.LENGTH_LONG).show();
                if(i==0){
                    Intent userSettings = new Intent(getApplicationContext(), UserSettings.class);
                    startActivity(userSettings);
                }else if(i==1){
                    Intent userSettings = new Intent(getApplicationContext(), FoodPreferencesActivity.class);
                    startActivity(userSettings);
                }else if(i==2){
                    Intent followerSettings = new Intent(getApplicationContext(), FollowRequests.class);
                    startActivity(followerSettings);
                }else if(i==3){
                    Intent privacySettings = new Intent(getApplicationContext(), PrivacySettings.class);
                    startActivity(privacySettings);
                }
            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            Intent allSetting = new Intent(getApplicationContext(), AllSettings.class);
            startActivity(allSetting);
            return true;
        }
        else if(id == R.id.action_logout){
            MyApplication myApplication = (MyApplication) getApplicationContext();
            myApplication.reset();
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            return true;
        }else if(id == R.id.action_profile){
            Intent intent = new Intent(this, ProfileActivity.class);
            startActivity(intent);
            return true;
        }
        else if(id == R.id.search){
            Intent intent = new Intent(this, SearchActivity.class);
            startActivity(intent);
            return true;
        }else if(id == R.id.home){
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
