package group1.nutty;

import android.app.Activity;
import android.app.ActivityGroup;
import android.app.TabActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import group1.nutty.R;

public class HelloWorldActivity extends ActivityGroup {

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hello_world);

    }
}
