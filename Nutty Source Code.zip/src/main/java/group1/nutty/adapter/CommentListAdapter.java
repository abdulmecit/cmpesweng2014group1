package group1.nutty.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import group1.nutty.MyApplication;
import group1.nutty.R;
import group1.nutty.UserProfileActivity;
import group1.nutty.group1.nutty.asynctask.DeleteCommentTask;
import group1.nutty.group1.nutty.asynctask.DeleteRecipeTask;
import group1.nutty.group1.nutty.asynctask.LikeCommentTask;
import group1.nutty.group1.nutty.asynctask.ShareRecipeTask;
import group1.nutty.model.Comment;

/**
* Created by gokhanonalan on 17/11/14.
*/
public class CommentListAdapter extends ArrayAdapter<Comment> {
    private final ArrayList<Comment> comments;
    private final Context context;
    private final boolean isUser;
    private CommentListAdapter self;

    public CommentListAdapter(Context context, ArrayList<Comment> comments, boolean isUser) {
        super(context, R.layout.comment_layout, comments);
        this.context = context;
        this.comments=comments;
        this.isUser=isUser;
        self = this;
    }

    private static class ViewHolder {
        private ImageView userPhoto;
        private TextView userName;
        private TextView commentText;
        private ToggleButton likeButton;
        private Button reportButton;
        private TextView likeCount;
        private TextView reportCount;
        private Button deleteComment;
    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        View view = null;

        if (convertView == null) {
            LayoutInflater inflator = LayoutInflater.from(this.getContext());
            view = inflator.inflate(R.layout.comment_layout, null);
            final ViewHolder viewHolder = new ViewHolder();
            viewHolder.commentText = (TextView) view.findViewById(R.id.commentText);
            viewHolder.userPhoto = (ImageView) view.findViewById(R.id.userPhoto);
            viewHolder.userName = (TextView) view.findViewById(R.id.userName);
            viewHolder.likeButton = (ToggleButton) view.findViewById(R.id.like);
            viewHolder.reportButton = (Button) view.findViewById(R.id.report);
            viewHolder.likeCount = (TextView) view.findViewById(R.id.likeCount);
            viewHolder.reportCount = (TextView) view.findViewById(R.id.reportCount);
            viewHolder.deleteComment = (Button) view.findViewById(R.id.deleteComment);
            view.setTag(viewHolder);
        } else {
            view = convertView;
        }
        ViewHolder holder = (ViewHolder) view.getTag();
        holder.commentText.setText(comments.get(position).getText());
        holder.userName.setText(comments.get(position).getCommenter());
        holder.likeCount.setText(Integer.toString(comments.get(position).getComment_likes()));


        holder.deleteComment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DeleteCommentTask deleteCommentTask = new DeleteCommentTask(comments.get(position).getComment_id());
                deleteCommentTask.execute();
                comments.remove(position);
                self.notifyDataSetChanged();
            }
        });



        if(!isUser){
            holder.likeButton.setVisibility(View.GONE);
            holder.reportButton.setVisibility(View.GONE);
            holder.likeCount.setText("Likes: "+comments.get(position).getCommentLikes()+"  ");
            holder.reportCount.setText("Reports: 5");
            holder.deleteComment.setVisibility(View.GONE);
        }else{
//            holder.likeCount.setText(comments.get(position).getCommentLikes());
            if(comments.get(position).getUser_id() != MyApplication.getUser().getId()){
                holder.deleteComment.setVisibility(View.GONE);
            }
            for(int likerID : comments.get(position).getLikerIDs()){
                if(likerID == MyApplication.getUser().getId()){
                    holder.likeButton.setChecked(true);
                }
            }
            holder.reportButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ReportCommentTask reportCommentTask = new ReportCommentTask(MyApplication.getUser().getId(), comments.get(position).getComment_id());
                    reportCommentTask.execute();
                    Toast.makeText(context, "Comment is reported!", Toast.LENGTH_LONG).show();
                }
            });
            holder.likeButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    LikeCommentTask likeCommentTask;
                    if(isChecked){
                        likeCommentTask = new LikeCommentTask(MyApplication.getUser().getId(), comments.get(position).getComment_id(), 1);
                    }else{
                        likeCommentTask = new LikeCommentTask(MyApplication.getUser().getId(), comments.get(position).getComment_id(), 0);
                    }
                    likeCommentTask.execute();
                }
            });
        }

        holder.userName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent userProfileActivity = new Intent(context, UserProfileActivity.class);
                userProfileActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                userProfileActivity.putExtra("id", (int) comments.get(position).getUser_id());
                context.startActivity(userProfileActivity);
            }
        });



        return view;

    }
    public class ReportCommentTask extends AsyncTask<Void, Void, String> {

        int commentID;
        int userID;

        InputStream is = null ;
        String result = "";

        public ReportCommentTask(int userID, int commentID) {
            this.commentID = commentID;
            this.userID = userID;
        }

        @Override
        protected String doInBackground(Void... params) {

            HttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost("http://titan.cmpe.boun.edu.tr:8080/nutty/reportComment?comment_id="+commentID+"&user_id="+userID);
            try {
                HttpResponse httpResponse = httpClient.execute(httpPost);
                HttpEntity httpEntity = httpResponse.getEntity();
                //read content
                is =  httpEntity.getContent();
                Thread.sleep(2000);
            }catch (Exception e) {
                Log.e("log_tag", "Error in http connection " + e.toString());
                return e.toString();
            }
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                StringBuilder sb = new StringBuilder();
                String line = "";
                while((line=br.readLine())!=null){
                    sb.append(line+"\n");
                }
                is.close();
                result=sb.toString();
            }catch (Exception e) {
                Log.e("log_tag", "Error converting result " + e.toString());
            }
            return result;
        }

        @Override
        protected void onPostExecute(final String result) {


        }
    }
}
