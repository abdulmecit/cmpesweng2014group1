package group1.nutty.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import group1.nutty.R;
import group1.nutty.RecipeActivity;
import group1.nutty.UserProfileActivity;
import group1.nutty.group1.nutty.asynctask.DownloadImageTask;
import group1.nutty.model.Recipe;

/**
 * Created by gokhanonalan on 09/12/14.
 */
public class NewsFeedAdapter extends ArrayAdapter<JSONObject> {
    private final ArrayList<JSONObject> activities;
    private final Context context;

    public NewsFeedAdapter(Context context, ArrayList<JSONObject> activities) {
        super(context, R.layout.newsfeed_activity_layout, activities);
        this.context = context;
        this.activities=activities;
    }

    private static class ViewHolder {
        TextView date;
        TextView user;
        TextView activityType;
        TextView targetName;
        ImageView targetPhoto;
        LinearLayout target;
    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        View view = null;

        if (convertView == null) {
            LayoutInflater inflator = LayoutInflater.from(this.getContext());
            view = inflator.inflate(R.layout.newsfeed_activity_layout, null);
            final ViewHolder viewHolder = new ViewHolder();
            viewHolder.date = (TextView) view.findViewById(R.id.date);
            viewHolder.user = (TextView) view.findViewById(R.id.user);
            viewHolder.activityType = (TextView) view.findViewById(R.id.activityType);
            viewHolder.targetName = (TextView) view.findViewById(R.id.targetName);
            viewHolder.targetPhoto = (ImageView) view.findViewById(R.id.targetPhoto);
            viewHolder.target = (LinearLayout) view.findViewById(R.id.target);

            view.setTag(viewHolder);
        } else {
            view = convertView;
        }
        ViewHolder holder = (ViewHolder) view.getTag();
        final JSONObject theNew = activities.get(position);
        try {
            String isActAllowed = theNew.getString("is_act_allowed");
            String action = theNew.getString("action");
            String timeStamp = theNew.getString("timestamp");
            String userName = theNew.getJSONObject("user").getString("name") + " " + theNew.getJSONObject("user").getString("surname");
            String targetPhotoURL = theNew.getString("target_photo_url");
            String targetName;

            Long lon = new Long(timeStamp);
            Timestamp ts = new Timestamp(lon);

            holder.date.setText(ts.toString());
            holder.user.setText(userName+" ");
            if(action.equals("derive_recipe")){
                holder.activityType.setText("has derived a recipe:");
                targetName = theNew.getJSONObject("target").getString("name");
                holder.target.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            int recipeID = theNew.getJSONObject("target").getInt("recipe_id");
                            Intent intent = new Intent(context, RecipeActivity.class);
                            intent.putExtra("id", Integer.toString(recipeID));
                            context.startActivity(intent);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }else if(action.equals("eat_recipe")){
                holder.activityType.setText("has eaten a recipe:");
                targetName = theNew.getJSONObject("target").getString("name");
                holder.target.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            int recipeID = theNew.getJSONObject("target").getInt("recipe_id");
                            Intent intent = new Intent(context, RecipeActivity.class);
                            intent.putExtra("id", Integer.toString(recipeID));
                            context.startActivity(intent);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }else if(action.equals("like_recipe")){
                holder.activityType.setText("has liked a recipe:");
                targetName = theNew.getJSONObject("target").getString("name");
                holder.target.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            int recipeID = theNew.getJSONObject("target").getInt("recipe_id");
                            Intent intent = new Intent(context, RecipeActivity.class);
                            intent.putExtra("id", Integer.toString(recipeID));
                            context.startActivity(intent);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }else if(action.equals("share_recipe")){
                holder.activityType.setText("has shared a recipe:");
                targetName = theNew.getJSONObject("target").getString("name");
                holder.target.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            int recipeID = theNew.getJSONObject("target").getInt("recipe_id");
                            Intent intent = new Intent(context, RecipeActivity.class);
                            intent.putExtra("id", Integer.toString(recipeID));
                            context.startActivity(intent);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }else if(action.equals("rate_recipe")){
                holder.activityType.setText("has rated a recipe:");
                targetName = theNew.getJSONObject("target").getString("name");
                holder.target.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            int recipeID = theNew.getJSONObject("target").getInt("recipe_id");
                            Intent intent = new Intent(context, RecipeActivity.class);
                            intent.putExtra("id", Integer.toString(recipeID));
                            context.startActivity(intent);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }else if(action.equals("get_followed")){
                holder.activityType.setText("is now being followed by:");
                targetName = theNew.getJSONObject("target").getString("name") + " " + theNew.getJSONObject("target").getString("surname");
            }else if(action.equals("follow_user")){
                holder.activityType.setText("is now following:");
                targetName = theNew.getJSONObject("target").getString("name") + " " + theNew.getJSONObject("target").getString("surname");
                holder.target.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            int userID = theNew.getJSONObject("target").getInt("id");
                            Intent intent = new Intent(context, UserProfileActivity.class);
                            intent.putExtra("id", userID);
                            context.startActivity(intent);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }else if(action.equals("earn_badge")){
                holder.activityType.setText("has earned a new badge:");
                targetName = theNew.getJSONObject("target").getString("name");
                holder.target.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            int userID = theNew.getJSONObject("target").getInt("id");
                            Intent intent = new Intent(context, UserProfileActivity.class);
                            intent.putExtra("id", userID);
                            context.startActivity(intent);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }else{
                holder.activityType.setText("");
                targetName = theNew.getJSONObject("target").getString("name");
            }

            holder.targetName.setText(targetName);
            try{
                DownloadImageTask downloadImageTask = new DownloadImageTask(holder.targetPhoto);
                downloadImageTask.execute(targetPhotoURL);
            }catch(Exception e){
                holder.targetPhoto.setImageResource(R.drawable.nutty);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return view;
    }
}
