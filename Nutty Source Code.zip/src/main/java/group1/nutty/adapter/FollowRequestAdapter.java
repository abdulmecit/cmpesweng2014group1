package group1.nutty.adapter;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import group1.nutty.MyApplication;
import group1.nutty.R;
import group1.nutty.RecipeActivity;
import group1.nutty.group1.nutty.asynctask.DownloadImageTask;
import group1.nutty.model.Recipe;

/**
 * Created by gokhanonalan on 09/12/14.
 */
public class FollowRequestAdapter extends ArrayAdapter<String> {
    private final ArrayList<String> requests;
    private final Context context;

    public FollowRequestAdapter(Context context, ArrayList<String> requests) {
        super(context, R.layout.follow_request, requests);
        this.context = context;
        this.requests=requests;
    }

    private static class ViewHolder {
        TextView followerName;
        Button accept;
        Button reject;

    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        View view = null;

        if (convertView == null) {
            LayoutInflater inflator = LayoutInflater.from(this.getContext());
            view = inflator.inflate(R.layout.follow_request, null);
            final ViewHolder viewHolder = new ViewHolder();
            viewHolder.followerName = (TextView) view.findViewById(R.id.followerName);
            viewHolder.accept = (Button) view.findViewById(R.id.accept);
            viewHolder.reject = (Button) view.findViewById(R.id.reject);

            view.setTag(viewHolder);
        } else {
            view = convertView;
        }

        ViewHolder holder = (ViewHolder) view.getTag();
        String[] temp = requests.get(position).split("\\>");
        System.out.println(temp[1]);
        final int followerID = Integer.parseInt(temp[1].trim());
        String userName = temp[0];

        holder.followerName.setText(userName);

        holder.accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AnswerFollowRequestTask answerFollowRequestTask = new AnswerFollowRequestTask(followerID, MyApplication.getUser().getId(), 1);
                answerFollowRequestTask.execute();
                requests.remove(position);
                notifyDataSetChanged();
                Toast.makeText(getContext(),"Friend request accepted!", Toast.LENGTH_SHORT).show();
            }
        });

        holder.reject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AnswerFollowRequestTask answerFollowRequestTask = new AnswerFollowRequestTask(followerID, MyApplication.getUser().getId(), 0);
                answerFollowRequestTask.execute();
                requests.remove(position);
                notifyDataSetChanged();
                Toast.makeText(getContext(),"Friend request rejected!", Toast.LENGTH_SHORT).show();
            }
        });



        return view;
    }
    public class AnswerFollowRequestTask extends AsyncTask<Void, Void, String> {

        int followerID;
        int followedID;
        int value;

        InputStream is = null ;
        String result = "";

        public AnswerFollowRequestTask(int followerID, int followedID, int value) {
            this.followerID = followerID;
            this.followedID = followedID;
            this.value = value;
        }

        @Override
        protected String doInBackground(Void... params) {

            HttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost("http://titan.cmpe.boun.edu.tr:8080/nutty/user/answerFollowRequest?follower_id="+followerID+"&followed_id="+followedID+"&value="+value);
            try {
                HttpResponse httpResponse = httpClient.execute(httpPost);
                HttpEntity httpEntity = httpResponse.getEntity();
                //read content
                is =  httpEntity.getContent();
                Thread.sleep(2000);
            }catch (Exception e) {
                Log.e("log_tag", "Error in http connection " + e.toString());
                return e.toString();
            }
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                StringBuilder sb = new StringBuilder();
                String line = "";
                while((line=br.readLine())!=null){
                    sb.append(line+"\n");
                }
                is.close();
                result=sb.toString();
            }catch (Exception e) {
                Log.e("log_tag", "Error converting result " + e.toString());
            }
            return result;
        }

        @Override
        protected void onPostExecute(final String result) {
            System.out.println(result);
        }
    }
}
