package group1.nutty.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

import group1.nutty.R;
import group1.nutty.model.IngredientAmount;

/**
 * Created by gokhanonalan on 07/12/14.
 */
public class IngAmountAdapter2 extends ArrayAdapter<IngredientAmount> {
    private ArrayList<IngredientAmount> ingredients;
    private Context context;
    private IngAmountAdapter2 self;

    public IngAmountAdapter2(Context context, ArrayList<IngredientAmount> ingredients) {
        super(context,R.layout.ing_amount_layout2, ingredients);
        this.context = context;
        this.ingredients=ingredients;
        this.self = this;
    }

    private static class ViewHolder {
        private TextView ingName;
        private TextView ingAmount;
        private TextView ingUnit;
        private Button removeIngredient;
    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        View view = null;

        if (convertView == null) {
            LayoutInflater inflator = LayoutInflater.from(this.getContext());
            view = inflator.inflate(R.layout.ing_amount_layout2, null);
            final ViewHolder viewHolder = new ViewHolder();
            viewHolder.ingName = (TextView) view.findViewById(R.id.ingName);
            viewHolder.ingAmount = (TextView) view.findViewById(R.id.ingAmount);
            viewHolder.ingUnit = (TextView) view.findViewById(R.id.ingUnit);
            viewHolder.removeIngredient = (Button) view.findViewById(R.id.removeIng);
            view.setTag(viewHolder);
        } else {
            view = convertView;
        }
        ViewHolder holder = (ViewHolder) view.getTag();
        holder.removeIngredient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ingredients.remove(position);
                self.notifyDataSetChanged();
            }
        });
        holder.ingName.setText(ingredients.get(position).getIng_name() + " ");
        holder.ingAmount.setText(Double.toString(ingredients.get(position).getAmount()) + " ");
        holder.ingUnit.setText(ingredients.get(position).getMeas_type());

        return view;

    }
}
