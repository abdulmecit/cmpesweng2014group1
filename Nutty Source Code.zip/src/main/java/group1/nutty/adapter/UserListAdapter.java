package group1.nutty.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import group1.nutty.R;
import group1.nutty.RecipeActivity;
import group1.nutty.UserProfileActivity;
import group1.nutty.group1.nutty.asynctask.DownloadImageTask;
import group1.nutty.model.Comment;
import group1.nutty.model.User;

/**
 * Created by gokhanonalan on 08/12/14.
 */
public class UserListAdapter extends ArrayAdapter<User> {
    private final ArrayList<User> users;
    private final Context context;

    public UserListAdapter(Context context, ArrayList<User> users) {
        super(context, R.layout.user_search_result, users);
        this.context = context;
        this.users=users;
    }

    private static class ViewHolder {
        TextView userName;
        ImageView profPic;

    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        View view = null;

        if (convertView == null) {
            LayoutInflater inflator = LayoutInflater.from(this.getContext());
            view = inflator.inflate(R.layout.user_search_result, null);
            final ViewHolder viewHolder = new ViewHolder();
            viewHolder.userName = (TextView) view.findViewById(R.id.userName);
            viewHolder.profPic = (ImageView) view.findViewById(R.id.profPic);
            view.setTag(viewHolder);
        } else {
            view = convertView;
        }
        ViewHolder holder = (ViewHolder) view.getTag();
        holder.userName.setText(users.get(position).getName() + " " + users.get(position).getSurname());
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent userProfileActivity = new Intent(context, UserProfileActivity.class);
                userProfileActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                userProfileActivity.putExtra("id",users.get(position).getId());
                context.startActivity(userProfileActivity);
            }
        });

        DownloadImageTask downloadImageTask = new DownloadImageTask(holder.profPic);
        downloadImageTask.execute(users.get(position).getPhoto());

        return view;
    }
}
