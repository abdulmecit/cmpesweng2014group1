package group1.nutty.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import group1.nutty.R;
import group1.nutty.RecipeActivity;
import group1.nutty.group1.nutty.asynctask.DownloadImageTask;
import group1.nutty.model.Recipe;

/**
 * Created by gokhanonalan on 09/12/14.
 */
public class BasicSearchListAdapter extends ArrayAdapter<Recipe> {
    private final ArrayList<Recipe> recipes;
    private final Context context;

    public BasicSearchListAdapter(Context context, ArrayList<Recipe> recipes) {
        super(context, R.layout.user_search_result, recipes);
        this.context = context;
        this.recipes=recipes;
    }

    private static class ViewHolder {
        TextView recipeName;
        ImageView recipeImage;

    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        View view = null;

        if (convertView == null) {
            LayoutInflater inflator = LayoutInflater.from(this.getContext());
            view = inflator.inflate(R.layout.basic_search_result, null);
            final ViewHolder viewHolder = new ViewHolder();
            viewHolder.recipeName = (TextView) view.findViewById(R.id.recipeName);
            viewHolder.recipeImage = (ImageView) view.findViewById(R.id.recipeImage);

            view.setTag(viewHolder);
        } else {
            view = convertView;
        }
        ViewHolder holder = (ViewHolder) view.getTag();
        holder.recipeName.setText(recipes.get(position).getName());
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent recipeActivity = new Intent(context, RecipeActivity.class);
                recipeActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                recipeActivity.putExtra("id",Integer.toString(recipes.get(position).getRecipe_id()));
                context.startActivity(recipeActivity);
            }
        });

        if(recipes.get(position).getPhoto() != null){
            DownloadImageTask downloadImageTask = new DownloadImageTask(holder.recipeImage);
            downloadImageTask.execute(recipes.get(position).getPhoto());
        }

        return view;
    }
}
