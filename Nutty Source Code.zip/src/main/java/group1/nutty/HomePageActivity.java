package group1.nutty;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutionException;

import android.app.Activity;
import android.app.ActionBar;
import android.app.AlertDialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.v13.app.FragmentPagerAdapter;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import group1.nutty.adapter.BasicSearchListAdapter;
import group1.nutty.adapter.CommentListAdapter;
import group1.nutty.adapter.NewsFeedAdapter;
import group1.nutty.adapter.UserListAdapter;
import group1.nutty.group1.nutty.asynctask.CommentRecipeTask;
import group1.nutty.group1.nutty.asynctask.DeleteRecipeTask;
import group1.nutty.group1.nutty.asynctask.DownloadImageTask;
import group1.nutty.group1.nutty.asynctask.GetCommentsTask;
import group1.nutty.group1.nutty.asynctask.GetRecipeTask;
import group1.nutty.group1.nutty.asynctask.RateRecipeTask;
import group1.nutty.group1.nutty.asynctask.ShareRecipeTask;
import group1.nutty.model.Comment;
import group1.nutty.model.IngredientAmount;
import group1.nutty.model.Recipe;
import group1.nutty.model.SuperRecipe;
import group1.nutty.model.Tag;
import group1.nutty.model.User;

import com.google.gson.Gson;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class HomePageActivity extends Activity implements ActionBar.TabListener {

    /**
     * The {@link android.support.v4.view.PagerAdapter} that will provide
     * fragments for each of the sections. We use a
     * {@link FragmentPagerAdapter} derivative, which will keep every
     * loaded fragment in memory. If this becomes too memory intensive, it
     * may be best to switch to a
     * {@link android.support.v13.app.FragmentStatePagerAdapter}.
     */
    SectionsPagerAdapter mSectionsPagerAdapter;

    /**
     * The {@link ViewPager} that will host the section contents.
     */
    ViewPager mViewPager;

    static boolean isUser;

    static ArrayList<JSONObject> news = new ArrayList<JSONObject>();
    static ListView newsFeeds;
    static ListView recommendations;
    static ArrayAdapter<JSONObject> newsFeedAdapter;

    static Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe);
        context = getApplicationContext();

        if(MyApplication.getUser()==null){
            isUser = false;
        }else{
            isUser = true;
        }

        // Set up the action bar.
        final ActionBar actionBar = getActionBar();
        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);

        // Create the adapter that will return a fragment for each of the three
        // primary sections of the activity.
        mSectionsPagerAdapter = new SectionsPagerAdapter(getFragmentManager());

        // Set up the ViewPager with the sections adapter.
        mViewPager = (ViewPager) findViewById(R.id.pager);
        mViewPager.setAdapter(mSectionsPagerAdapter);

        // When swiping between different sections, select the corresponding
        // tab. We can also use ActionBar.Tab#select() to do this if we have
        // a reference to the Tab.
        mViewPager.setOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
            @Override
            public void onPageSelected(int position) {
                actionBar.setSelectedNavigationItem(position);
            }
        });

        // For each of the sections in the app, add a tab to the action bar.
        for (int i = 0; i < mSectionsPagerAdapter.getCount(); i++) {
            // Create a tab with text corresponding to the page title defined by
            // the adapter. Also specify this Activity object, which implements
            // the TabListener interface, as the callback (listener) for when
            // this tab is selected.
            actionBar.addTab(
                    actionBar.newTab()
                            .setText(mSectionsPagerAdapter.getPageTitle(i))
                            .setTabListener(this));
        }



    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            Intent allSetting = new Intent(getApplicationContext(), AllSettings.class);
            startActivity(allSetting);
            return true;
        }
        else if(id == R.id.action_logout){
            MyApplication myApplication = (MyApplication) getApplicationContext();
            myApplication.reset();
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            return true;
        }else if(id == R.id.action_profile){
            Intent intent = new Intent(this, ProfileActivity.class);
            startActivity(intent);
            return true;
        }
        else if(id == R.id.search){
            Intent intent = new Intent(this, SearchActivity.class);
            startActivity(intent);
            return true;
        }else if(id == R.id.home){
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onTabSelected(ActionBar.Tab tab, FragmentTransaction fragmentTransaction) {
        // When the given tab is selected, switch to the corresponding page in
        // the ViewPager.
        mViewPager.setCurrentItem(tab.getPosition());
    }

    @Override
    public void onTabUnselected(ActionBar.Tab tab, FragmentTransaction fragmentTransaction) {
    }

    @Override
    public void onTabReselected(ActionBar.Tab tab, FragmentTransaction fragmentTransaction) {
    }

    /**
     * A {@link FragmentPagerAdapter} that returns a fragment corresponding to
     * one of the sections/tabs/pages.
     */
    public class SectionsPagerAdapter extends FragmentPagerAdapter {

        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            // getItem is called to instantiate the fragment for the given page.
            // Return a PlaceholderFragment (defined as a static inner class below).
            if(position==0){
                return NewsFeedFragment.newInstance(position + 1);
            }else if(position==1){
                return RecommenadationFragment.newInstance(position + 1);
            }else{
                return NewsFeedFragment.newInstance(position + 1);
            }
        }

        @Override
        public int getCount() {
            // Show 2 total pages.
            return 2;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            Locale l = Locale.getDefault();
            switch (position) {
                case 0:
                    return getString(R.string.title_section4).toUpperCase(l);
                case 1:
                    return getString(R.string.title_section5).toUpperCase(l);
            }
            return null;
        }
    }

    /**
     * A placeholder fragment containing a simple view.
     */
    public static class NewsFeedFragment extends Fragment {
        /**
         * The fragment argument representing the section number for this
         * fragment.
         */
        private static final String ARG_SECTION_NUMBER = "section_number";

        /**
         * Returns a new instance of this fragment for the given section
         * number.
         */
        public static NewsFeedFragment newInstance(int sectionNumber) {
            NewsFeedFragment fragment = new NewsFeedFragment();
            Bundle args = new Bundle();
            args.putInt(ARG_SECTION_NUMBER, sectionNumber);
            fragment.setArguments(args);
            return fragment;
        }

        public NewsFeedFragment() {
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
            final View rootView = inflater.inflate(R.layout.fragment_home_page, container, false);

            newsFeeds = (ListView) rootView.findViewById(R.id.newsFeeds);


            GetRecentActivities getRecentActivities = new GetRecentActivities(MyApplication.getUser().getId(), rootView.getContext());
            getRecentActivities.execute();



            return rootView;
        }
    }

    public static class RecommenadationFragment extends Fragment {
        private static final String ARG_SECTION_NUMBER = "section_number";
        public static RecommenadationFragment newInstance(int sectionNumber) {
            RecommenadationFragment fragment = new RecommenadationFragment();
            Bundle args = new Bundle();
            args.putInt(ARG_SECTION_NUMBER, sectionNumber);
            fragment.setArguments(args);
            return fragment;
        }
        public RecommenadationFragment() {
        }
        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.fragment_basic_search, container, false);
            recommendations = (ListView) rootView.findViewById(R.id.basicSearchList);
            GetRecommendationTask getRecommendationTask = new GetRecommendationTask(MyApplication.getUser().getId());
            getRecommendationTask.execute();

            return rootView;
        }
    }

    public static class GetRecentActivities extends AsyncTask<Void, Void, String> {

        int userID;

        InputStream is = null ;
        String result = "";
        Context context;

        public GetRecentActivities(int userID, Context context) {
            this.userID = userID;
            this.context = context;
        }

        @Override
        public void onPreExecute(){
            news = new ArrayList<JSONObject>();
        }

        @Override
        protected String doInBackground(Void... params) {

            HttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost("http://titan.cmpe.boun.edu.tr:8080/nutty/getRecentEvents?user_id="+userID);
            try {
                HttpResponse httpResponse = httpClient.execute(httpPost);
                HttpEntity httpEntity = httpResponse.getEntity();
                //read content
                is =  httpEntity.getContent();
                Thread.sleep(2000);
            }catch (Exception e) {
                Log.e("log_tag", "Error in http connection " + e.toString());
                return e.toString();
            }
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                StringBuilder sb = new StringBuilder();
                String line = "";
                while((line=br.readLine())!=null){
                    sb.append(line+"\n");
                }
                is.close();
                result=sb.toString();
            }catch (Exception e) {
                Log.e("log_tag", "Error converting result " + e.toString());
            }
            return result;
        }

        @Override
        protected void onPostExecute(final String result) {
            System.out.println(result);
            try {
                JSONArray jsonArray = new JSONArray(result);
                for(int i=0; i<jsonArray.length(); i++){
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    if(jsonObject.getInt("is_act_allowed")==1){
                        news.add(jsonObject);
                    }
                }
                newsFeedAdapter = new NewsFeedAdapter(context, news);
                newsFeeds.setAdapter(newsFeedAdapter);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    public static class GetRecommendationTask extends AsyncTask<Void, Void, String> {

        int userID;

        InputStream is = null ;
        String result = "";

        ArrayList<Recipe> recipes = new ArrayList<Recipe>();

        GetRecommendationTask(int userID) {
            this.userID = userID;
        }

        @Override
        protected void onPreExecute(){

        }

        @Override
        protected String doInBackground(Void... params) {

            HttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost("http://titan.cmpe.boun.edu.tr:8080/nutty/getRecommendationREST?user_id="+userID);
            try {
                HttpResponse httpResponse = httpClient.execute(httpPost);
                HttpEntity httpEntity = httpResponse.getEntity();
                //read content
                is =  httpEntity.getContent();
                Thread.sleep(2000);
            }catch (Exception e) {
                Log.e("log_tag", "Error in http connection " + e.toString());
                return e.toString();
            }
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                StringBuilder sb = new StringBuilder();
                String line = "";
                while((line=br.readLine())!=null){
                    sb.append(line+"\n");
                }
                is.close();
                result=sb.toString();
            }catch (Exception e) {
                Log.e("log_tag", "Error converting result " + e.toString());
            }
            return result;
        }

        @Override
        protected void onPostExecute(final String result) {
            System.out.println(result);
            try {
                JSONArray recipeArray = new JSONArray(result);
                if(recipeArray.length()>0){
                    for(int i=0;i<recipeArray.length();i++) {
                        JSONObject recipeData = recipeArray.getJSONObject(i);
                        Recipe recipe = new Recipe();
                        recipe.setName(recipeData.getString("name"));
                        recipe.setRecipe_id(Integer.parseInt(recipeData.getString("id")));
                        recipe.setPhoto(recipeData.getString("photoUrl"));
                        recipes.add(recipe);
                    }
                }else{
                }
                ArrayAdapter recipeAdapter = new BasicSearchListAdapter(context, recipes);
                recommendations.setAdapter(recipeAdapter);

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }

        @Override
        protected void onCancelled() {

        }
    }

}
