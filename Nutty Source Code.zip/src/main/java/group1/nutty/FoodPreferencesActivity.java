package group1.nutty;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.Configuration;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.preference.EditTextPreference;
import android.preference.ListPreference;
import android.preference.MultiSelectListPreference;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.preference.RingtonePreference;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.support.v4.app.NavUtils;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.google.gson.Gson;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * A {@link PreferenceActivity} that presents a set of application settings. On
 * handset devices, settings are presented as a single list. On tablets,
 * settings are split by category, with category headers shown to the left of
 * the list of settings.
 * <p>
 * See <a href="http://developer.android.com/design/patterns/settings.html">
 * Android Design: Settings</a> for design guidelines and the <a
 * href="http://developer.android.com/guide/topics/ui/settings.html">Settings
 * API Guide</a> for more information on developing a Settings UI.
 */
public class FoodPreferencesActivity extends PreferenceActivity {
    /**
     * Determines whether to always show the simplified settings UI, where
     * settings are presented in a single list. When false, settings are shown
     * as a master/detail two-pane view on tablets. When true, a single pane is
     * shown on tablets.
     */
    private static final boolean ALWAYS_SIMPLE_PREFS = false;

    private MultiSelectListPreference intoleranceAndAllergies;
    private MultiSelectListPreference diseases;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupActionBar();
        GetFoodSelectionTask getFoodSelectionTask = new GetFoodSelectionTask(MyApplication.getUser().getId());
        getFoodSelectionTask.execute();
    }

    /**
     * Set up the {@link android.app.ActionBar}, if the API is available.
     */
    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    private void setupActionBar() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            // Show the Up button in the action bar.
            getActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            // This ID represents the Home or Up button. In the case of this
            // activity, the Up button is shown. Use NavUtils to allow users
            // to navigate up one level in the application structure. For
            // more details, see the Navigation pattern on Android Design:
            //
            // http://developer.android.com/design/patterns/navigation.html#up-vs-back
            //
            // TODO: If Settings has multiple levels, Up should navigate up
            // that hierarchy.
            NavUtils.navigateUpFromSameTask(this);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);

        setupSimplePreferencesScreen();
    }

    /**
     * Shows the simplified settings UI if the device configuration if the
     * device configuration dictates that a simplified, single-pane UI should be
     * shown.
     */
    private void setupSimplePreferencesScreen() {
        if (!isSimplePreferences(this)) {
            return;
        }

        addPreferencesFromResource(R.xml.pref_food);

        intoleranceAndAllergies = (MultiSelectListPreference) findPreference("intoleranceAndAllergies");
        diseases = (MultiSelectListPreference) findPreference("diseases");


        diseases.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
            @Override
            public boolean onPreferenceChange(Preference preference, Object newValue) {
                MultiSelectListPreference myPref = (MultiSelectListPreference) preference;
                String[] diseasesSet = ((Set<String>) newValue).toArray(new String[((Set<String>) newValue).size()]);
                String[] intoleranceAndAllergiesSet = intoleranceAndAllergies.getValues().toArray(new String[intoleranceAndAllergies.getValues().size()]);
                String[] foodSelectionArray = new String[diseasesSet.length+intoleranceAndAllergiesSet.length];
                for(int i=0; i<diseasesSet.length; i++){
                    foodSelectionArray[i] = diseasesSet[i];
                }
                for(int i=diseasesSet.length; i<foodSelectionArray.length; i++){
                    foodSelectionArray[i] = intoleranceAndAllergiesSet[i-diseasesSet.length];
                }

                for(String s : foodSelectionArray){
                    System.out.println(s);
                }
                myPref.setValues((Set<String>) newValue);
                Gson gson = new Gson();
                String json = gson.toJson(foodSelectionArray, String[].class);
                SetFoodSelectionTask setFoodSelectionTask = new SetFoodSelectionTask(MyApplication.getUser().getId(), json);
                setFoodSelectionTask.execute();
                return false;
            }
        });
        intoleranceAndAllergies.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
            @Override
            public boolean onPreferenceChange(Preference preference, Object newValue) {
                MultiSelectListPreference myPref = (MultiSelectListPreference) preference;
                String[] diseasesSet = diseases.getValues().toArray(new String[myPref.getValues().size()]);
                String[] intoleranceAndAllergiesSet = ((Set<String>) newValue).toArray(new String[((Set<String>) newValue).size()]);
                String[] foodSelectionArray = new String[diseasesSet.length+intoleranceAndAllergiesSet.length];
                for(int i=0; i<diseasesSet.length; i++){
                    foodSelectionArray[i] = diseasesSet[i];
                }
                for(int i=diseasesSet.length; i<foodSelectionArray.length; i++){
                    foodSelectionArray[i] = intoleranceAndAllergiesSet[i-diseasesSet.length];
                }
                for(String s : foodSelectionArray){
                    System.out.println(s);
                }
                myPref.setValues((Set<String>) newValue);

                Gson gson = new Gson();
                String json = gson.toJson(foodSelectionArray, String[].class);
                SetFoodSelectionTask setFoodSelectionTask = new SetFoodSelectionTask(MyApplication.getUser().getId(), json);
                setFoodSelectionTask.execute();
                return false;
            }
        });


    }

    /** {@inheritDoc} */
    @Override
    public boolean onIsMultiPane() {
        return isXLargeTablet(this) && !isSimplePreferences(this);
    }

    /**
     * Helper method to determine if the device has an extra-large screen. For
     * example, 10" tablets are extra-large.
     */
    private static boolean isXLargeTablet(Context context) {
        return (context.getResources().getConfiguration().screenLayout
        & Configuration.SCREENLAYOUT_SIZE_MASK) >= Configuration.SCREENLAYOUT_SIZE_XLARGE;
    }

    /**
     * Determines whether the simplified settings UI should be shown. This is
     * true if this is forced via {@link #ALWAYS_SIMPLE_PREFS}, or the device
     * doesn't have newer APIs like {@link PreferenceFragment}, or the device
     * doesn't have an extra-large screen. In these cases, a single-pane
     * "simplified" settings UI should be shown.
     */
    private static boolean isSimplePreferences(Context context) {
        return ALWAYS_SIMPLE_PREFS
                || Build.VERSION.SDK_INT < Build.VERSION_CODES.HONEYCOMB
                || !isXLargeTablet(context);
    }

    /** {@inheritDoc} */
    @Override
    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    public void onBuildHeaders(List<Header> target) {
        if (!isSimplePreferences(this)) {
            loadHeadersFromResource(R.xml.pref_headers, target);
        }
    }

    /**
     * A preference value change listener that updates the preference's summary
     * to reflect its new value.
     */
    private static Preference.OnPreferenceChangeListener sBindPreferenceSummaryToValueListener = new Preference.OnPreferenceChangeListener() {
        @Override
        public boolean onPreferenceChange(Preference preference, Object value) {
            String stringValue = value.toString();

            if (preference instanceof ListPreference) {
                // For list preferences, look up the correct display value in
                // the preference's 'entries' list.
                ListPreference listPreference = (ListPreference) preference;
                int index = listPreference.findIndexOfValue(stringValue);

                // Set the summary to reflect the new value.
                preference.setSummary(
                        index >= 0
                                ? listPreference.getEntries()[index]
                                : null);

            } else {
                // For all other preferences, set the summary to the value's
                // simple string representation.
                preference.setSummary(stringValue);
            }
            return true;
        }
    };

    /**
     * Binds a preference's summary to its value. More specifically, when the
     * preference's value is changed, its summary (line of text below the
     * preference title) is updated to reflect the value. The summary is also
     * immediately updated upon calling this method. The exact display format is
     * dependent on the type of preference.
     *
     * @see #sBindPreferenceSummaryToValueListener
     */
    private static void bindPreferenceSummaryToValue(Preference preference) {
        // Set the listener to watch for value changes.
        preference.setOnPreferenceChangeListener(sBindPreferenceSummaryToValueListener);

        // Trigger the listener immediately with the preference's
        // current value.
        sBindPreferenceSummaryToValueListener.onPreferenceChange(preference,
                PreferenceManager
                        .getDefaultSharedPreferences(preference.getContext())
                        .getString(preference.getKey(), ""));
    }

    /**
     * This fragment shows general preferences only. It is used when the
     * activity is showing a two-pane settings UI.
     */
    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    public static class GeneralPreferenceFragment extends PreferenceFragment {
        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            addPreferencesFromResource(R.xml.pref_food);
        }
    }
    public class SetFoodSelectionTask extends AsyncTask<Void, Void, String> {
        int userID;
        String foodSelection;

        InputStream is = null ;
        String result = "";

        public SetFoodSelectionTask(int userID, String foodSelection) {
            this.userID = userID;
            this.foodSelection = foodSelection;
        }

        @Override
        protected String doInBackground(Void... params) {

            HttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost("http://titan.cmpe.boun.edu.tr:8080/nutty/user/addFoodSelectionsREST?user_id="+userID);
            try {
                ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
                nameValuePairs.add(new BasicNameValuePair("FoodSelection[]", foodSelection));
                httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                HttpResponse httpResponse = httpClient.execute(httpPost);
                HttpEntity httpEntity = httpResponse.getEntity();
                //read content
                is =  httpEntity.getContent();
                Thread.sleep(2000);
            }catch (Exception e) {
                Log.e("log_tag", "Error in http connection " + e.toString());
                return e.toString();
            }
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                StringBuilder sb = new StringBuilder();
                String line = "";
                while((line=br.readLine())!=null){
                    sb.append(line+"\n");
                }
                is.close();
                result=sb.toString();
            }catch (Exception e) {
                Log.e("log_tag", "Error converting result " + e.toString());
            }
            return result;
        }

        @Override
        protected void onPostExecute(final String result) {
            System.out.println(result);
            try {
                JSONArray jsonArray = new JSONArray(result);

                Set<String> diseasesSet = new HashSet<String>();
                Set<String> intoleranceAndAllergiesSet = new HashSet<String>();
                for(int i=0; i<jsonArray.length(); i++){
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    if(jsonObject.getString("type").equals("food_intolerance")){
                        intoleranceAndAllergiesSet.add(jsonObject.getString("fs_name"));
                    }else if(jsonObject.getString("type").equals("health_condition")){
                        diseasesSet.add(jsonObject.getString("fs_name"));
                    }
                }
                diseases.setValues(diseasesSet);
                intoleranceAndAllergies.setValues(intoleranceAndAllergiesSet);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public class AddUnpreferredTask extends AsyncTask<Void, Void, String> {
        int userID;
        String unpreferred;

        InputStream is = null ;
        String result = "";

        public AddUnpreferredTask(int userID, String unpreferred) {
            this.userID = userID;
            this.unpreferred = unpreferred;
        }

        @Override
        protected String doInBackground(Void... params) {

            HttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost("http://titan.cmpe.boun.edu.tr:8080/nutty/user/addUnpreferredREST?user_id="+userID);
            try {
                ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
                nameValuePairs.add(new BasicNameValuePair("unpreferred", unpreferred));
                httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                HttpResponse httpResponse = httpClient.execute(httpPost);
                HttpEntity httpEntity = httpResponse.getEntity();
                //read content
                is =  httpEntity.getContent();
                Thread.sleep(2000);
            }catch (Exception e) {
                Log.e("log_tag", "Error in http connection " + e.toString());
                return e.toString();
            }
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                StringBuilder sb = new StringBuilder();
                String line = "";
                while((line=br.readLine())!=null){
                    sb.append(line+"\n");
                }
                is.close();
                result=sb.toString();
            }catch (Exception e) {
                Log.e("log_tag", "Error converting result " + e.toString());
            }
            return result;
        }

        @Override
        protected void onPostExecute(final String result) {
            System.out.println(result);
            try {
                JSONArray jsonArray = new JSONArray(result);

                Set<String> diseasesSet = new HashSet<String>();
                Set<String> intoleranceAndAllergiesSet = new HashSet<String>();
                for(int i=0; i<jsonArray.length(); i++){
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    if(jsonObject.getString("type").equals("food_intolerance")){
                        intoleranceAndAllergiesSet.add(jsonObject.getString("fs_name"));
                    }else if(jsonObject.getString("type").equals("health_condition")){
                        diseasesSet.add(jsonObject.getString("fs_name"));
                    }
                }
                diseases.setValues(diseasesSet);
                intoleranceAndAllergies.setValues(intoleranceAndAllergiesSet);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public class GetFoodSelectionTask extends AsyncTask<Void, Void, String> {
        int userID;

        InputStream is = null ;
        String result = "";

        public GetFoodSelectionTask(int userID) {
            this.userID = userID;
        }

        @Override
        protected String doInBackground(Void... params) {

            HttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost("http://titan.cmpe.boun.edu.tr:8080/nutty/user/foodSelectionREST?user_id="+userID);
            try {
                HttpResponse httpResponse = httpClient.execute(httpPost);
                HttpEntity httpEntity = httpResponse.getEntity();
                //read content
                is =  httpEntity.getContent();
                Thread.sleep(2000);
            }catch (Exception e) {
                Log.e("log_tag", "Error in http connection " + e.toString());
                return e.toString();
            }
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                StringBuilder sb = new StringBuilder();
                String line = "";
                while((line=br.readLine())!=null){
                    sb.append(line+"\n");
                }
                is.close();
                result=sb.toString();
            }catch (Exception e) {
                Log.e("log_tag", "Error converting result " + e.toString());
            }
            return result;
        }

        @Override
        protected void onPostExecute(final String result) {
            System.out.println(result);
            try {
                JSONArray jsonArray = new JSONArray(result);

                Set<String> diseasesSet = new HashSet<String>();
                Set<String> intoleranceAndAllergiesSet = new HashSet<String>();
                for(int i=0; i<jsonArray.length(); i++){
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    if(jsonObject.getString("type").equals("food_intolerance")){
                        intoleranceAndAllergiesSet.add(jsonObject.getString("fs_name"));
                    }else if(jsonObject.getString("type").equals("health_condition")){
                        diseasesSet.add(jsonObject.getString("fs_name"));
                    }
                }
                diseases.setValues(diseasesSet);
                intoleranceAndAllergies.setValues(intoleranceAndAllergiesSet);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }





}
