package group1.nutty;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutionException;

import android.app.Activity;
import android.app.ActionBar;
import android.app.AlertDialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.v13.app.FragmentPagerAdapter;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import group1.nutty.adapter.BasicSearchListAdapter;
import group1.nutty.adapter.CommentListAdapter;
import group1.nutty.group1.nutty.asynctask.CommentRecipeTask;
import group1.nutty.group1.nutty.asynctask.DeleteRecipeTask;
import group1.nutty.group1.nutty.asynctask.DownloadImageTask;
import group1.nutty.group1.nutty.asynctask.GetCommentsTask;
import group1.nutty.group1.nutty.asynctask.GetRecipeTask;
import group1.nutty.group1.nutty.asynctask.RateRecipeTask;
import group1.nutty.group1.nutty.asynctask.ShareRecipeTask;
import group1.nutty.model.Comment;
import group1.nutty.model.IngredientAmount;
import group1.nutty.model.Recipe;
import group1.nutty.model.SuperRecipe;
import group1.nutty.model.Tag;

import com.google.gson.Gson;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class RecipeActivity extends Activity implements ActionBar.TabListener {

    /**
     * The {@link android.support.v4.view.PagerAdapter} that will provide
     * fragments for each of the sections. We use a
     * {@link FragmentPagerAdapter} derivative, which will keep every
     * loaded fragment in memory. If this becomes too memory intensive, it
     * may be best to switch to a
     * {@link android.support.v13.app.FragmentStatePagerAdapter}.
     */
    SectionsPagerAdapter mSectionsPagerAdapter;

    /**
     * The {@link ViewPager} that will host the section contents.
     */
    ViewPager mViewPager;
    Gson gson = new Gson();
    static SuperRecipe superRecipe;
    static Bitmap bitmap;

    static boolean isUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe);

        if(MyApplication.getUser()==null){
            isUser = false;
        }else{
            isUser = true;
        }


        superRecipe  = new SuperRecipe();

        // Set up the action bar.
        final ActionBar actionBar = getActionBar();
        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);

        // Create the adapter that will return a fragment for each of the three
        // primary sections of the activity.
        mSectionsPagerAdapter = new SectionsPagerAdapter(getFragmentManager());

        // Set up the ViewPager with the sections adapter.
        mViewPager = (ViewPager) findViewById(R.id.pager);
        mViewPager.setAdapter(mSectionsPagerAdapter);

        // When swiping between different sections, select the corresponding
        // tab. We can also use ActionBar.Tab#select() to do this if we have
        // a reference to the Tab.
        mViewPager.setOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
            @Override
            public void onPageSelected(int position) {
                actionBar.setSelectedNavigationItem(position);
            }
        });

        // For each of the sections in the app, add a tab to the action bar.
        for (int i = 0; i < mSectionsPagerAdapter.getCount(); i++) {
            // Create a tab with text corresponding to the page title defined by
            // the adapter. Also specify this Activity object, which implements
            // the TabListener interface, as the callback (listener) for when
            // this tab is selected.
            actionBar.addTab(
                    actionBar.newTab()
                            .setText(mSectionsPagerAdapter.getPageTitle(i))
                            .setTabListener(this));
        }
        Intent intent = getIntent();
        String recipeId = intent.getStringExtra("id");

        String recipe = "";

        try {
            recipe = new GetRecipeTask().execute(recipeId).get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
        System.out.println(recipe);

        try {

            JSONObject jsonObject = new JSONObject(recipe);
            Recipe recipeObj = new Recipe(jsonObject.getJSONObject("recipe"));

            try{
                JSONArray ingredientAmounts = jsonObject.getJSONArray("ingredientAmounts");
                for(int i=0; i<ingredientAmounts.length(); i++){
                    superRecipe.addIngredientAmounts(gson.fromJson(ingredientAmounts.get(i).toString(), IngredientAmount.class));
                }
            }catch(Exception e){
                superRecipe.setIngredientAmounts(new ArrayList<IngredientAmount>());
            }
            try{
                JSONArray commentsInfo = jsonObject.getJSONArray("comments");
                JSONArray commenters = jsonObject.getJSONArray("commenterNames");
                JSONArray commentLikerIDs = jsonObject.getJSONArray("commentLikerIds");
                for(int i=0; i<commentsInfo.length(); i++){
                    if(commentLikerIDs.length() != 0){
                        superRecipe.addComment(new Comment(commentsInfo.getJSONObject(i), commenters.getString(i), commentLikerIDs.getJSONArray(i)));
                    }else{
                        superRecipe.addComment(new Comment(commentsInfo.getJSONObject(i), commenters.getString(i)));
                    }

                }
            }catch(Exception e){
                System.out.println("asdfg");
                superRecipe.setComments(new ArrayList<Comment>());
            }
            try{
                JSONArray tags = jsonObject.getJSONArray("tags");
                for(int i=0; i<tags.length(); i++){
                    superRecipe.addTag(gson.fromJson(tags.getString(i), Tag.class));
                }
            }catch(Exception e){
                superRecipe.setTags(new ArrayList<Tag>());
            }
            superRecipe.setAvgCostRate(jsonObject.getDouble("avgCostRate"));
            superRecipe.setAvgEaseRate(jsonObject.getDouble("avgEaseRate"));
            superRecipe.setAvgHealthRate(jsonObject.getDouble("avgHealthRate"));
            superRecipe.setAvgTasteRate(jsonObject.getDouble("avgTasteRate"));
            superRecipe.setNoOfEats(jsonObject.getInt("noOfEats"));
            superRecipe.setNoOfLikes(jsonObject.getInt("noOfLikes"));
            superRecipe.setOwner(jsonObject.getString("owner"));
            try{
                superRecipe.setPhotoUrl(jsonObject.getJSONArray("photoUrl").getString(0));
            }catch(Exception e){
                superRecipe.setPhotoUrl("");
            }
            superRecipe.setRecipe(recipeObj);

            if(!jsonObject.isNull("parent")){
                superRecipe.setParent(new Recipe(jsonObject.getJSONObject("parent")));
                System.out.println(superRecipe.getParent().getRecipe_id());
            }
            if(!jsonObject.isNull("children")){
                for(int i=0; i<jsonObject.getJSONArray("children").length(); i++){
                    superRecipe.addChild(new Recipe(jsonObject.getJSONArray("children").getJSONObject(i)));
                }

            }


        } catch (JSONException e) {
            e.printStackTrace();
            superRecipe = null;
        }


    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            if(isUser){
                Intent allSetting = new Intent(getApplicationContext(), AllSettings.class);
                startActivity(allSetting);
            }else{
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
            }

            return true;
        }
        else if(id == R.id.action_logout){
            MyApplication myApplication = (MyApplication) getApplicationContext();
            myApplication.reset();
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            return true;
        }else if(id == R.id.action_profile){
            if(isUser){
                Intent intent = new Intent(this, ProfileActivity.class);
                startActivity(intent);
            }else{
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
            }
            return true;
        }
        else if(id == R.id.search){
            Intent intent = new Intent(this, SearchActivity.class);
            startActivity(intent);
            return true;
        }else if(id == R.id.home){
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onTabSelected(ActionBar.Tab tab, FragmentTransaction fragmentTransaction) {
        // When the given tab is selected, switch to the corresponding page in
        // the ViewPager.
        mViewPager.setCurrentItem(tab.getPosition());
    }

    @Override
    public void onTabUnselected(ActionBar.Tab tab, FragmentTransaction fragmentTransaction) {
    }

    @Override
    public void onTabReselected(ActionBar.Tab tab, FragmentTransaction fragmentTransaction) {
    }

    /**
     * A {@link FragmentPagerAdapter} that returns a fragment corresponding to
     * one of the sections/tabs/pages.
     */
    public class SectionsPagerAdapter extends FragmentPagerAdapter {

        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            // getItem is called to instantiate the fragment for the given page.
            // Return a PlaceholderFragment (defined as a static inner class below).
            if(position==0){
                return RecipeFragment.newInstance(position + 1);
            }else if(position==1){
                return CommentFragment.newInstance(position + 1);
            }else if(position==2){
                return RelationFragment.newInstance(position + 1);
            }else{
                return RecipeFragment.newInstance(position + 1);
            }
        }

        @Override
        public int getCount() {
            // Show 3 total pages.
            if(isUser){
                return 3;
            }else{
                return 2;
            }

        }

        @Override
        public CharSequence getPageTitle(int position) {
            Locale l = Locale.getDefault();
            switch (position) {
                case 0:
                    return getString(R.string.title_section1).toUpperCase(l);
                case 1:
                    return getString(R.string.title_section2).toUpperCase(l);
                case 2:
                    return getString(R.string.title_section3).toUpperCase(l);
            }
            return null;
        }
    }

    /**
     * A placeholder fragment containing a simple view.
     */
    public static class RecipeFragment extends Fragment {
        /**
         * The fragment argument representing the section number for this
         * fragment.
         */
        private static final String ARG_SECTION_NUMBER = "section_number";

        /**
         * Returns a new instance of this fragment for the given section
         * number.
         */
        public static RecipeFragment newInstance(int sectionNumber) {
            RecipeFragment fragment = new RecipeFragment();
            Bundle args = new Bundle();
            args.putInt(ARG_SECTION_NUMBER, sectionNumber);
            fragment.setArguments(args);
            return fragment;
        }

        public RecipeFragment() {
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
            final View rootView = inflater.inflate(R.layout.fragment_recipe, container, false);
            if(superRecipe != null){
                final TextView recipeName = (TextView) rootView.findViewById(R.id.recipeName);
                recipeName.setText(superRecipe.getRecipe().getName());

                final TextView userName = (TextView) rootView.findViewById(R.id.userName);
                userName.setText("by "+superRecipe.getOwner());

                final TextView portionNumber= (TextView) rootView.findViewById(R.id.portion);
                portionNumber.setText("Portion: "+superRecipe.getRecipe().getPortion());

                final TextView totalCalorie = (TextView) rootView.findViewById(R.id.totalCalorie);
                totalCalorie.setText("Total Calorie: "+superRecipe.getRecipe().getTotal_calorie() +" kcal");

                final TextView totalProtein = (TextView) rootView.findViewById(R.id.totalProtein);
                totalProtein.setText("Total Protein: "+superRecipe.getRecipe().getTotal_protein() +" gr");

                final TextView totalFat = (TextView) rootView.findViewById(R.id.totalFat);
                totalFat.setText("Total Fat: "+superRecipe.getRecipe().getTotal_fat() +" gr");

                final TextView totalCarbs = (TextView) rootView.findViewById(R.id.totalCarbs);
                totalCarbs.setText("Total Carbohydrate: "+superRecipe.getRecipe().getTotal_carbohydrate() +" gr");

                final RatingBar tasteBar = (RatingBar) rootView.findViewById(R.id.tasteBar);
                tasteBar.setRating((float) superRecipe.getAvgTasteRate());

                final RatingBar easeBar = (RatingBar) rootView.findViewById(R.id.easeBar);
                easeBar.setRating((float) superRecipe.getAvgEaseRate());

                final RatingBar costRate = (RatingBar) rootView.findViewById(R.id.costBar);
                costRate.setRating((float) superRecipe.getAvgCostRate());

                final RatingBar healthBar = (RatingBar) rootView.findViewById(R.id.healthBar);
                healthBar.setRating((float) superRecipe.getAvgHealthRate());

                final ToggleButton shareButton = (ToggleButton) rootView.findViewById(R.id.share);

                final ToggleButton likeDislike = (ToggleButton) rootView.findViewById(R.id.likeDislike);

                final CheckBox eaten = (CheckBox) rootView.findViewById(R.id.eaten);

                final TextView noOfLikes = (TextView) rootView.findViewById(R.id.noOfLikes);
                noOfLikes.setText(Integer.toString(superRecipe.getNoOfLikes()));

                final TextView noOfEats = (TextView) rootView.findViewById(R.id.noOfEats);
                noOfEats.setText(Integer.toString(superRecipe.getNoOfEats()));

                final ImageView recipeImage = (ImageView) rootView.findViewById(R.id.recipeImage);
                new DownloadImageTask(recipeImage).execute(superRecipe.getPhotoUrl());

                LinearLayout ingredients = (LinearLayout) rootView.findViewById(R.id.ingredients);
                ingredients.removeAllViewsInLayout();
                for(IngredientAmount ingredientAmount : superRecipe.getIngredientAmounts()){
                    TextView ingredientAmountText = new TextView(rootView.getContext());
                    ingredientAmountText.setText(ingredientAmount.getIng_name() + "   " + ingredientAmount.getAmount() + "  " + ingredientAmount.getMeas_type());
                    ingredientAmountText.setTextColor(Color.BLACK);
                    ingredientAmountText.setGravity(Gravity.CENTER_HORIZONTAL);
                    ingredients.addView(ingredientAmountText);
                }
                final TextView instruction = (TextView) rootView.findViewById(R.id.instruction);
                instruction.setText(superRecipe.getRecipe().getDescription());
                instruction.setTextColor(Color.BLACK);

                final Button reportButton = (Button) rootView.findViewById(R.id.report);

                final Button deleteButton = (Button) rootView.findViewById(R.id.deleteRecipe);
                deleteButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                switch (which){
                                    case DialogInterface.BUTTON_POSITIVE:
                                        DeleteRecipeTask deleteRecipeTask = new DeleteRecipeTask(superRecipe.getRecipe().getRecipe_id());
                                        deleteRecipeTask.execute();
                                        Intent intent = new Intent(getActivity(), ProfileActivity.class);
                                        startActivity(intent);
                                        break;

                                    case DialogInterface.BUTTON_NEGATIVE:
                                        //No button clicked
                                        break;
                                }
                            }
                        };

                        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setMessage("Are you sure you want to delete your recipe?").setPositiveButton("Yes", dialogClickListener)
                                .setNegativeButton("No", dialogClickListener).show();
                    }
                });

                Button deriveRecipe = (Button) rootView.findViewById(R.id.deriveRecipe);
                deriveRecipe.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(rootView.getContext(), DeriveRecipeActivity.class);
                        Gson gson1 = new Gson();
                        intent.putExtra("recipe", gson1.toJson(superRecipe, SuperRecipe.class));
                        startActivity(intent);
                    }
                });


                if(isUser){
                    tasteBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
                        @Override
                        public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                            RateRecipeTask rateRecipeTask = new RateRecipeTask("taste_rate", MyApplication.getUser().getId(),superRecipe.getRecipe().getRecipe_id(),(int) rating);
                            rateRecipeTask.execute();
                        }
                    });
                    easeBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
                        @Override
                        public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                            RateRecipeTask rateRecipeTask = new RateRecipeTask("ease_rate", MyApplication.getUser().getId(),superRecipe.getRecipe().getRecipe_id(),(int) rating);
                            rateRecipeTask.execute();
                        }
                    });
                    costRate.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
                        @Override
                        public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                            RateRecipeTask rateRecipeTask = new RateRecipeTask("cost_rate", MyApplication.getUser().getId(),superRecipe.getRecipe().getRecipe_id(),(int) rating);
                            rateRecipeTask.execute();
                        }
                    });
                    healthBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
                        @Override
                        public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                            RateRecipeTask rateRecipeTask = new RateRecipeTask("health_rate", MyApplication.getUser().getId(),superRecipe.getRecipe().getRecipe_id(),(int) rating);
                            rateRecipeTask.execute();
                        }
                    });
                    shareButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            ShareRecipeTask shareRecipeTask;
                            if(shareButton.getText().toString().equals("Unshare")){
                                shareRecipeTask = new ShareRecipeTask(MyApplication.getUser().getId(),superRecipe.getRecipe().getRecipe_id(),1);
                            }else{
                                shareRecipeTask = new ShareRecipeTask(MyApplication.getUser().getId(),superRecipe.getRecipe().getRecipe_id(),0);
                            }
                            shareRecipeTask.execute();
                        }
                    });

                    reportButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            ReportRecipeTask reportRecipeTask = new ReportRecipeTask(MyApplication.getUser().getId(), superRecipe.getRecipe().getRecipe_id());
                            reportRecipeTask.execute();
                            Toast.makeText(rootView.getContext(),"Recipe is reported!", Toast.LENGTH_LONG).show();
                        }
                    });

                    GetELROfUserTask getELROfUserTask = new GetELROfUserTask(MyApplication.getUser().getId(), superRecipe.getRecipe().getRecipe_id(), likeDislike, shareButton, eaten);
                    getELROfUserTask.execute();
                    if(MyApplication.getUser().recipeIsFromUser(superRecipe.getRecipe().getRecipe_id())){

                    }else{
                        deleteButton.setVisibility(View.GONE);
                    }

                }else{
                    tasteBar.setIsIndicator(true);
                    easeBar.setIsIndicator(true);
                    costRate.setIsIndicator(true);
                    healthBar.setIsIndicator(true);
                    shareButton.setVisibility(View.GONE);
                    likeDislike.setVisibility(View.GONE);
                    eaten.setVisibility(View.GONE);
                    noOfLikes.setText("Likes: "+superRecipe.getNoOfLikes()+"  ");
                    noOfEats.setText("Eaten: "+superRecipe.getNoOfEats());
                    deleteButton.setVisibility(View.GONE);
                    reportButton.setVisibility(View.GONE);
                    deriveRecipe.setVisibility(View.GONE);
                }




            }else{
                Toast.makeText(rootView.getContext(),"Error getting the recipe!",Toast.LENGTH_LONG);
            }

            return rootView;
        }
    }

    public static class CommentFragment extends Fragment {
        private static final String ARG_SECTION_NUMBER = "section_number";
        public static CommentFragment newInstance(int sectionNumber) {
            CommentFragment fragment = new CommentFragment();
            Bundle args = new Bundle();
            args.putInt(ARG_SECTION_NUMBER, sectionNumber);
            fragment.setArguments(args);
            return fragment;
        }
        public CommentFragment() {
        }
        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.fragment_comment, container, false);
            if(superRecipe != null){
                final ListView comments = (ListView) rootView.findViewById(R.id.comments);
                final ArrayAdapter<Comment> adapter = new CommentListAdapter(rootView.getContext(), superRecipe.getComments(), isUser);
                comments.setAdapter(adapter);

                final EditText comment = (EditText) rootView.findViewById(R.id.comment);
                final Button makeComment = (Button) rootView.findViewById(R.id.makeComment);

                if(!isUser){
                    comment.setVisibility(View.GONE);
                    makeComment.setVisibility(View.GONE);
                }else{
                    makeComment.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            String commentText = comment.getText().toString();
                            if(!commentText.equals("")){
                                CommentRecipeTask commentRecipeTask = new CommentRecipeTask((long)MyApplication.getUser().getId(),superRecipe.getRecipe().getRecipe_id(),commentText);
                                commentRecipeTask.execute();
                                Comment newComment = new Comment();
                                newComment.setText(commentText);
                                newComment.setCommenter(MyApplication.getUser().getName()+" "+MyApplication.getUser().getSurname());
                                newComment.setUser_id(MyApplication.getUser().getId());
                                adapter.add(newComment);
                                comment.setText("");
                            }
                        }
                    });
                }
            }


            return rootView;
        }
    }

    public static class RelationFragment extends Fragment {
        private static final String ARG_SECTION_NUMBER = "section_number";
        public static RelationFragment newInstance(int sectionNumber) {
            RelationFragment fragment = new RelationFragment();
            Bundle args = new Bundle();
            args.putInt(ARG_SECTION_NUMBER, sectionNumber);
            fragment.setArguments(args);
            return fragment;
        }
        public RelationFragment() {
        }
        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            final View rootView = inflater.inflate(R.layout.fragment_relation, container, false);

            if(superRecipe.getParent() != null){
                TextView parentName = (TextView) rootView.findViewById(R.id.parentName);
                parentName.setText(superRecipe.getParent().getName());
                LinearLayout parent = (LinearLayout) rootView.findViewById(R.id.parent);
                parent.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent recipeActivity = new Intent(rootView.getContext(), RecipeActivity.class);
                        recipeActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        recipeActivity.putExtra("id", Integer.toString(superRecipe.getParent().getRecipe_id()));
                        rootView.getContext().startActivity(recipeActivity);
                    }
                });
            }

            final ListView children = (ListView) rootView.findViewById(R.id.children);
            if(superRecipe.getChildren().size() != 0){
                ArrayAdapter recipeAdapter = new BasicSearchListAdapter(rootView.getContext(), superRecipe.getChildren());
                children.setAdapter(recipeAdapter);
            }else{
                ArrayList<Recipe> noRecipes = new ArrayList<Recipe>();
                Recipe recipe = new Recipe();
                recipe.setName("There are no children!");
                noRecipes.add(recipe);
                ArrayAdapter recipeAdapter = new BasicSearchListAdapter(rootView.getContext(), noRecipes);
                children.setAdapter(recipeAdapter);
            }


            return rootView;
        }
    }

    public static class ReportRecipeTask extends AsyncTask<Void, Void, String> {

        long recipeID;
        int userID;

        InputStream is = null ;
        String result = "";

        public ReportRecipeTask(int userID, int recipeID) {
            this.recipeID = recipeID;
            this.userID = userID;
        }

        @Override
        protected String doInBackground(Void... params) {

            HttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost("http://titan.cmpe.boun.edu.tr:8080/nutty/reportRecipe?recipe_id="+recipeID+"&user_id="+userID);
            try {
                HttpResponse httpResponse = httpClient.execute(httpPost);
                HttpEntity httpEntity = httpResponse.getEntity();
                //read content
                is =  httpEntity.getContent();
                Thread.sleep(2000);
            }catch (Exception e) {
                Log.e("log_tag", "Error in http connection " + e.toString());
                return e.toString();
            }
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                StringBuilder sb = new StringBuilder();
                String line = "";
                while((line=br.readLine())!=null){
                    sb.append(line+"\n");
                }
                is.close();
                result=sb.toString();
            }catch (Exception e) {
                Log.e("log_tag", "Error converting result " + e.toString());
            }
            return result;
        }

        @Override
        protected void onPostExecute(final String result) {


        }
    }

    public static class GetELROfUserTask extends AsyncTask<Void, Void, String> {
        int userID;
        int recipeID;
        ToggleButton likeButton;
        ToggleButton shareButton;
        CheckBox eaten;

        InputStream is = null ;
        String result = "";

        GetELROfUserTask(int userID, int recipeID, ToggleButton likeButton, ToggleButton shareButton, CheckBox eaten) {
            this.userID = userID;
            this.recipeID = recipeID;
            this.likeButton = likeButton;
            this.shareButton = shareButton;
            this.eaten = eaten;
        }

        @Override
        protected String doInBackground(Void... params) {

            HttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost("http://titan.cmpe.boun.edu.tr:8080/nutty/elrOfUser?recipeId="+recipeID+"&user_id="+userID);
            try {
                HttpResponse httpResponse = httpClient.execute(httpPost);
                HttpEntity httpEntity = httpResponse.getEntity();
                //read content
                is =  httpEntity.getContent();
                Thread.sleep(2000);
            }catch (Exception e) {
                Log.e("log_tag", "Error in http connection " + e.toString());
                return e.toString();
            }
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                StringBuilder sb = new StringBuilder();
                String line = "";
                while((line=br.readLine())!=null){
                    sb.append(line+"\n");
                }
                is.close();
                result=sb.toString();
            }catch (Exception e) {
                Log.e("log_tag", "Error converting result " + e.toString());
            }
            return result;
        }

        @Override
        protected void onPostExecute(final String result) {
            System.out.println(result);
            try {
                JSONObject jsonObject = new JSONObject(result);
                if(jsonObject.getInt("likeOfUser") == 1){
                    likeButton.setChecked(true);
                }
                if(jsonObject.getInt("shareOfUser") == 1){
                    shareButton.setChecked(true);
                }
                if(jsonObject.getInt("eatenOfUser") == 1){
                    eaten.setChecked(true);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

}
