package group1.nutty.group1.nutty.asynctask;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.google.gson.Gson;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class GetMeasureTypeTask extends AsyncTask<Void, Void, String> {
    String ingName;
    Spinner spinner;
    Context context;

    InputStream is = null ;
    String result = "";

    public GetMeasureTypeTask(String ingName, Spinner spinner, Context context) {
        this.ingName = ingName;
        this.spinner = spinner;
        this.context = context;
    }

    @Override
    protected String doInBackground(Void... params) {

        HttpClient httpClient = new DefaultHttpClient();
        HttpPost httpPost = new HttpPost("http://titan.cmpe.boun.edu.tr:8080/nutty/measTypesOfIngr2");
        try {
            ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
            nameValuePairs.add(new BasicNameValuePair("ing_name", ingName));
            httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
            HttpResponse httpResponse = httpClient.execute(httpPost);
            HttpEntity httpEntity = httpResponse.getEntity();
            //read content
            is =  httpEntity.getContent();
            Thread.sleep(2000);
        }catch (Exception e) {
            Log.e("log_tag", "Error in http connection " + e.toString());
            return e.toString();
        }
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            StringBuilder sb = new StringBuilder();
            String line = "";
            while((line=br.readLine())!=null){
                sb.append(line+"\n");
            }
            is.close();
            result=sb.toString();
        }catch (Exception e) {
            Log.e("log_tag", "Error converting result " + e.toString());
        }
        return result;
    }

    @Override
    protected void onPostExecute(final String result) {
        System.out.println(result);
        try {
            Gson gson = new Gson();
            String[] temp = gson.fromJson(result, String[].class);
            String[] measureTypes = new String[temp.length+1];
            measureTypes[0] = "gram";
            for(int i=1; i<measureTypes.length; i++){
                measureTypes[i] = temp[i-1];
            }
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, measureTypes);

            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


            spinner.setAdapter(adapter);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
