package group1.nutty.group1.nutty.asynctask;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class GetIngredientsTask extends AsyncTask<Void, Void, String> {
    InputStream is = null ;
    String result = "";

    String ingName;
    AutoCompleteTextView textView;
    ArrayList<String> ingNames;
    ArrayAdapter<String> adapter;
    Context context;

    public GetIngredientsTask(String ingName, AutoCompleteTextView textView, Context context) {
        this.ingName = ingName;
        this.textView = textView;
        this.context = context;
    }

    @Override
    protected void onPreExecute(){
        ingNames = new ArrayList<String>();
    }

    @Override
    protected String doInBackground(Void... params) {

        HttpClient httpClient = new DefaultHttpClient();
        HttpPost httpPost = new HttpPost("http://titan.cmpe.boun.edu.tr:8080/nutty/someIngredients2?filter="+ingName);
        try {
            HttpResponse httpResponse = httpClient.execute(httpPost);
            HttpEntity httpEntity = httpResponse.getEntity();
            //read content
            is =  httpEntity.getContent();
            Thread.sleep(2000);
        }catch (Exception e) {
            Log.e("log_tag", "Error in http connection " + e.toString());
//                return e.toString();
            return null;
        }
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            StringBuilder sb = new StringBuilder();
            String line = "";
            while((line=br.readLine())!=null){
                sb.append(line+"\n");
            }
            is.close();
            result=sb.toString();
        }catch (Exception e) {
            Log.e("log_tag", "Error converting result " + e.toString());
        }
        return result;
    }

    @Override
    protected void onPostExecute(final String result) {
        try {
            JSONArray jsonArray = new JSONArray(result);
            String[] temp = new String[jsonArray.length()];
            for(int i=0; i<jsonArray.length(); i++){
                JSONObject object = (JSONObject) jsonArray.get(i);
                temp[i] = object.getString("ing_name");
            }
//                while (keys.hasNext()) {
//                    String key = (String) keys.next();
//                    ingIDs.add(Integer.parseInt(key));
//                    ingNames.add(jsonObject.getString(key));
//                }
            System.out.println(temp);
            adapter = new ArrayAdapter<String>(
                    context, android.R.layout.select_dialog_item, temp);
            textView.setThreshold(1);
            textView.setAdapter(adapter);

            adapter.notifyDataSetChanged();
            System.out.println(adapter.getCount());
            System.out.println(textView.getAdapter().getCount());

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onCancelled() {
    }
}