package group1.nutty.group1.nutty.asynctask;

import android.os.AsyncTask;
import android.util.Log;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * Created by Huseyin on 27.12.2014.
 */
public class DeleteCommentTask extends AsyncTask<Void, Void, String> {

    long commentID;

    InputStream is = null ;
    String result = "";

    public DeleteCommentTask(int commentID) {
        this.commentID = commentID;
    }

    @Override
    protected String doInBackground(Void... params) {

        HttpClient httpClient = new DefaultHttpClient();
        HttpPost httpPost = new HttpPost("http://titan.cmpe.boun.edu.tr:8080/nutty/deleteComment?comment_id="+commentID);
        try {
            HttpResponse httpResponse = httpClient.execute(httpPost);
            HttpEntity httpEntity = httpResponse.getEntity();
            //read content
            is =  httpEntity.getContent();
            Thread.sleep(2000);
        }catch (Exception e) {
            Log.e("log_tag", "Error in http connection " + e.toString());
            return e.toString();
        }
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            StringBuilder sb = new StringBuilder();
            String line = "";
            while((line=br.readLine())!=null){
                sb.append(line+"\n");
            }
            is.close();
            result=sb.toString();
        }catch (Exception e) {
            Log.e("log_tag", "Error converting result " + e.toString());
        }
        return result;
    }

    @Override
    protected void onPostExecute(final String result) {
        System.out.println(result);
    }
}
