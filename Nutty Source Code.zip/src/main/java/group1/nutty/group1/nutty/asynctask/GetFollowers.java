package group1.nutty.group1.nutty.asynctask;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.ListView;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import group1.nutty.adapter.FollowRequestAdapter;

public class GetFollowers extends AsyncTask<Void, Void, String> {

    long userID;
    ListView followerRequests;
    Context context;

    InputStream is = null ;
    String result = "";

    public GetFollowers(Context context, long userID, ListView followerRequests) {
        this.followerRequests = followerRequests;
        this.userID = userID;
        this.context = context;
    }

    @Override
    protected String doInBackground(Void... params) {

        HttpClient httpClient = new DefaultHttpClient();
        HttpPost httpPost = new HttpPost("http://titan.cmpe.boun.edu.tr:8080/nutty/user/getFollowRequests?user_id="+userID);
        try {
            HttpResponse httpResponse = httpClient.execute(httpPost);
            HttpEntity httpEntity = httpResponse.getEntity();
            //read content
            is =  httpEntity.getContent();
            Thread.sleep(2000);
        }catch (Exception e) {
            Log.e("log_tag", "Error in http connection " + e.toString());
            return e.toString();
        }
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            StringBuilder sb = new StringBuilder();
            String line = "";
            while((line=br.readLine())!=null){
                sb.append(line+"\n");
            }
            is.close();
            result=sb.toString();
        }catch (Exception e) {
            Log.e("log_tag", "Error converting result " + e.toString());
        }
        return result;
    }

    @Override
    protected void onPostExecute(final String result) {
        ArrayList<String> arr = new ArrayList<String>();
        System.out.println(result);
        try{
            String[] temp = result.split("\\|");
            for(int i=1; i<temp.length; i++){
                System.out.println(temp[i]);
                arr.add(temp[i]);
            }
            FollowRequestAdapter followRequestAdapter = new FollowRequestAdapter(context,arr);
            followerRequests.setAdapter(followRequestAdapter);
        }catch(Exception e){
            System.out.println("Hata var");
        }

    }
}
