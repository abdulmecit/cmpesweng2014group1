package group1.nutty.group1.nutty.asynctask;

import android.os.AsyncTask;
import android.util.Log;

import com.google.gson.Gson;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * Created by gokhanonalan on 17/12/14.
 */
public class GetUserRecipesTask extends AsyncTask<Void, Void, String> {

    long userID;

    InputStream is = null ;
    String result = "";

    GetUserRecipesTask(long userID) {
        this.userID = userID;

    }

    @Override
    protected String doInBackground(Void... params) {

        HttpClient httpClient = new DefaultHttpClient();
        HttpPost httpPost = new HttpPost("http://titan.cmpe.boun.edu.tr:8080/nutty/user/getUsersRecipes?userId="+userID);
        try {
            HttpResponse httpResponse = httpClient.execute(httpPost);
            HttpEntity httpEntity = httpResponse.getEntity();
            //read content
            is =  httpEntity.getContent();
            Thread.sleep(2000);
        }catch (Exception e) {
            Log.e("log_tag", "Error in http connection " + e.toString());
            return e.toString();
        }
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            StringBuilder sb = new StringBuilder();
            String line = "";
            while((line=br.readLine())!=null){
                sb.append(line+"\n");
            }
            is.close();
            result=sb.toString();
        }catch (Exception e) {
            Log.e("log_tag", "Error converting result " + e.toString());
        }
        return result;
    }

    @Override
    protected void onPostExecute(final String result) {
        System.out.println(result);
        try {
            Gson gson = new Gson();
            String[][] recipes = gson.fromJson(result, String[][].class);



        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
