package group1.nutty;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.preference.EditTextPreference;
import android.preference.ListPreference;
import android.preference.MultiSelectListPreference;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.preference.RingtonePreference;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.support.v4.app.NavUtils;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import group1.nutty.group1.nutty.asynctask.GetPrivacyOptionsTask;

public class PrivacySettings extends PreferenceActivity {

    private static final boolean ALWAYS_SIMPLE_PREFS = false;

    CheckBoxPreference followable;
    CheckBoxPreference healthConditions;
    CheckBoxPreference foodIntolerance;
    CheckBoxPreference notPreferred;
    CheckBoxPreference activities;

    String json = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupActionBar();
        GetPrivacyOptionsTask getPrivacyOptionsTask = new GetPrivacyOptionsTask(MyApplication.getUser().getId());

        try {
            json = getPrivacyOptionsTask.execute().get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    private void setupActionBar() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            // Show the Up button in the action bar.
            getActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            NavUtils.navigateUpFromSameTask(this);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);

        setupSimplePreferencesScreen();
    }

    private void setupSimplePreferencesScreen() {
        if (!isSimplePreferences(this)) {
            return;
        }
        addPreferencesFromResource(R.xml.pref_privacy);

        followable = (CheckBoxPreference) findPreference("followable");
        healthConditions = (CheckBoxPreference) findPreference("healthConditions");
        foodIntolerance = (CheckBoxPreference) findPreference("foodIntolerance");
        notPreferred = (CheckBoxPreference) findPreference("notPreferred");
        activities = (CheckBoxPreference) findPreference("activities");
        if(!json.equals("")){
            try {
                JSONObject jsonObject = new JSONObject(json);
                if(jsonObject.getInt("followable")==0){
                    followable.setChecked(true);
                }
                if(jsonObject.getInt("visible_health_condition")==0){
                    healthConditions.setChecked(true);
                }
                if(jsonObject.getInt("visible_food_intolerance")==0){
                    foodIntolerance.setChecked(true);
                }
                if(jsonObject.getInt("visible_not_pref")==0){
                    notPreferred.setChecked(true);
                }
                if(jsonObject.getInt("visible_activities")==0){
                    activities.setChecked(true);
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }

        followable.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
            @Override
            public boolean onPreferenceChange(Preference preference, Object newValue) {
                Boolean bool = (Boolean) newValue;
                int followableInt;
                if(bool.booleanValue()){
                    followableInt = 0;
                }else{
                    followableInt = 1;
                }
                int healthCon = 1;
                int foodInt = 1;
                int notPref = 1;
                int activity = 1;
                if(healthConditions.isChecked()){
                    healthCon = 0;
                }
                if(foodIntolerance.isChecked()){
                    foodInt = 0;
                }
                if(notPreferred.isChecked()){
                    notPref = 0;
                }
                if(activities.isChecked()){
                    activity = 0;
                }
                PrivacySettingsTask privacySettingsTask = new PrivacySettingsTask(followableInt, healthCon, foodInt, notPref, activity);
                privacySettingsTask.execute();


                return true;
            }
        });

        healthConditions.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
            @Override
            public boolean onPreferenceChange(Preference preference, Object newValue) {
                Boolean bool = (Boolean) newValue;
                int followableInt = 1;
                int healthCon = 1;
                int foodInt = 1;
                int notPref = 1;
                int activity = 1;
                if(bool.booleanValue()){
                    healthCon = 0;
                }else{
                    healthCon = 1;
                }
                if(followable.isChecked()){
                    followableInt = 0;
                }
                if(foodIntolerance.isChecked()){
                    foodInt = 0;
                }
                if(notPreferred.isChecked()){
                    notPref = 0;
                }
                if(activities.isChecked()){
                    activity = 0;
                }
                PrivacySettingsTask privacySettingsTask = new PrivacySettingsTask(followableInt, healthCon, foodInt, notPref, activity);
                privacySettingsTask.execute();


                return true;
            }
        });

        foodIntolerance.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
            @Override
            public boolean onPreferenceChange(Preference preference, Object newValue) {
                Boolean bool = (Boolean) newValue;
                int followableInt = 1;
                int healthCon = 1;
                int foodInt = 1;
                int notPref = 1;
                int activity = 1;
                if(bool.booleanValue()){
                    foodInt = 0;
                }else{
                    foodInt = 1;
                }
                if(healthConditions.isChecked()){
                    healthCon = 0;
                }
                if(followable.isChecked()){
                    followableInt = 0;
                }
                if(notPreferred.isChecked()){
                    notPref = 0;
                }
                if(activities.isChecked()){
                    activity = 0;
                }
                PrivacySettingsTask privacySettingsTask = new PrivacySettingsTask(followableInt, healthCon, foodInt, notPref, activity);
                privacySettingsTask.execute();


                return true;
            }
        });

        notPreferred.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
            @Override
            public boolean onPreferenceChange(Preference preference, Object newValue) {
                Boolean bool = (Boolean) newValue;
                int followableInt = 1;
                int healthCon = 1;
                int foodInt = 1;
                int notPref = 1;
                int activity = 1;
                if(bool.booleanValue()){
                    notPref = 0;
                }else{
                    notPref = 1;
                }
                if(healthConditions.isChecked()){
                    healthCon = 0;
                }
                if(foodIntolerance.isChecked()){
                    foodInt = 0;
                }
                if(followable.isChecked()){
                    followableInt = 0;
                }
                if(activities.isChecked()){
                    activity = 0;
                }
                PrivacySettingsTask privacySettingsTask = new PrivacySettingsTask(followableInt, healthCon, foodInt, notPref, activity);
                privacySettingsTask.execute();


                return true;
            }
        });

        activities.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
            @Override
            public boolean onPreferenceChange(Preference preference, Object newValue) {
                Boolean bool = (Boolean) newValue;
                int followableInt = 1;
                int healthCon = 1;
                int foodInt = 1;
                int notPref = 1;
                int activity = 1;
                if(bool.booleanValue()){
                    activity = 0;
                }else{
                    activity = 1;
                }
                if(healthConditions.isChecked()){
                    healthCon = 0;
                }
                if(foodIntolerance.isChecked()){
                    foodInt = 0;
                }
                if(notPreferred.isChecked()){
                    notPref = 0;
                }
                if(followable.isChecked()){
                    followableInt = 0;
                }
                PrivacySettingsTask privacySettingsTask = new PrivacySettingsTask(followableInt, healthCon, foodInt, notPref, activity);
                privacySettingsTask.execute();


                return true;
            }
        });

    }

    /** {@inheritDoc} */
    @Override
    public boolean onIsMultiPane() {
        return isXLargeTablet(this) && !isSimplePreferences(this);
    }

    /**
     * Helper method to determine if the device has an extra-large screen. For
     * example, 10" tablets are extra-large.
     */
    private static boolean isXLargeTablet(Context context) {
        return (context.getResources().getConfiguration().screenLayout
                & Configuration.SCREENLAYOUT_SIZE_MASK) >= Configuration.SCREENLAYOUT_SIZE_XLARGE;
    }

    /**
     * Determines whether the simplified settings UI should be shown. This is
     * true if this is forced via {@link #ALWAYS_SIMPLE_PREFS}, or the device
     * doesn't have newer APIs like {@link PreferenceFragment}, or the device
     * doesn't have an extra-large screen. In these cases, a single-pane
     * "simplified" settings UI should be shown.
     */
    private static boolean isSimplePreferences(Context context) {
        return ALWAYS_SIMPLE_PREFS
                || Build.VERSION.SDK_INT < Build.VERSION_CODES.HONEYCOMB
                || !isXLargeTablet(context);
    }

    /** {@inheritDoc} */
    @Override
    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    public void onBuildHeaders(List<Header> target) {
        if (!isSimplePreferences(this)) {
            loadHeadersFromResource(R.xml.pref_headers, target);
        }
    }

    /**
     * A preference value change listener that updates the preference's summary
     * to reflect its new value.
     */
    private static Preference.OnPreferenceChangeListener sBindPreferenceSummaryToValueListener = new Preference.OnPreferenceChangeListener() {
        @Override
        public boolean onPreferenceChange(Preference preference, Object value) {
            String stringValue = value.toString();

            if (preference instanceof ListPreference) {
                // For list preferences, look up the correct display value in
                // the preference's 'entries' list.
                ListPreference listPreference = (ListPreference) preference;
                int index = listPreference.findIndexOfValue(stringValue);

                // Set the summary to reflect the new value.
                preference.setSummary(
                        index >= 0
                                ? listPreference.getEntries()[index]
                                : null);

            }  else {
                // For all other preferences, set the summary to the value's
                // simple string representation.
                preference.setSummary(stringValue);
            }
            return true;
        }
    };

    /**
     * Binds a preference's summary to its value. More specifically, when the
     * preference's value is changed, its summary (line of text below the
     * preference title) is updated to reflect the value. The summary is also
     * immediately updated upon calling this method. The exact display format is
     * dependent on the type of preference.
     *
     * @see #sBindPreferenceSummaryToValueListener
     */
    private static void bindPreferenceSummaryToValue(Preference preference) {
        // Set the listener to watch for value changes.
        preference.setOnPreferenceChangeListener(sBindPreferenceSummaryToValueListener);

        // Trigger the listener immediately with the preference's
        // current value.
        sBindPreferenceSummaryToValueListener.onPreferenceChange(preference,
                PreferenceManager
                        .getDefaultSharedPreferences(preference.getContext())
                        .getString(preference.getKey(), ""));
    }

    /**
     * This fragment shows general preferences only. It is used when the
     * activity is showing a two-pane settings UI.
     */
    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    public static class GeneralPreferenceFragment extends PreferenceFragment {
        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            addPreferencesFromResource(R.xml.pref_user);

            // Bind the summaries of EditText/List/Dialog/Ringtone preferences
            // to their values. When their values change, their summaries are
            // updated to reflect the new value, per the Android Design
            // guidelines.
            bindPreferenceSummaryToValue(findPreference("followable"));
            bindPreferenceSummaryToValue(findPreference("healthConditions"));
            bindPreferenceSummaryToValue(findPreference("foodIntolerance"));
            bindPreferenceSummaryToValue(findPreference("notPreferred"));
            bindPreferenceSummaryToValue(findPreference("activities"));
        }
    }
    public class PrivacySettingsTask extends AsyncTask<Void, Void, String> {

        int followable;
        int healthCon;
        int foodIntolerance;
        int notPreferred;
        int activity;

        InputStream is = null ;
        String result = "";

        public PrivacySettingsTask(int followable, int healthCon, int foodIntolerance, int notPreferred, int activity) {
            this.followable =followable;
            this.foodIntolerance=foodIntolerance;
            this.notPreferred =notPreferred;
            this.activity=activity;
            this.healthCon=healthCon;

        }

        @Override
        protected String doInBackground(Void... params) {

            HttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost("http://titan.cmpe.boun.edu.tr:8080/nutty/user/updatePrivacyOptionsREST?user_id="+MyApplication.getUser().getId()+"&followable="+followable+"&visible_hc="+healthCon+"&visible_fi="+foodIntolerance+"&visible_np="+notPreferred+"&visible_ac="+activity);
            try {
                HttpResponse httpResponse = httpClient.execute(httpPost);
                HttpEntity httpEntity = httpResponse.getEntity();
                //read content
                is =  httpEntity.getContent();
                Thread.sleep(2000);
            }catch (Exception e) {
                Log.e("log_tag", "Error in http connection " + e.toString());
                return e.toString();
            }
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                StringBuilder sb = new StringBuilder();
                String line = "";
                while((line=br.readLine())!=null){
                    sb.append(line+"\n");
                }
                is.close();
                result=sb.toString();
            }catch (Exception e) {
                Log.e("log_tag", "Error converting result " + e.toString());
            }
            return result;
        }

        @Override
        protected void onPostExecute(final String result) {
            System.out.println(result);
        }
    }
}
