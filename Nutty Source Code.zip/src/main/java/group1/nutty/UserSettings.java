package group1.nutty;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.preference.EditTextPreference;
import android.preference.ListPreference;
import android.preference.MultiSelectListPreference;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.preference.RingtonePreference;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.support.v4.app.NavUtils;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class UserSettings extends PreferenceActivity {

    private static final boolean ALWAYS_SIMPLE_PREFS = false;
    private EditTextPreference email;
    private EditTextPreference name;
    private EditTextPreference surname;
    private EditTextPreference password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupActionBar();
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    private void setupActionBar() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            // Show the Up button in the action bar.
            getActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            NavUtils.navigateUpFromSameTask(this);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);

        setupSimplePreferencesScreen();
    }

    private void setupSimplePreferencesScreen() {
        if (!isSimplePreferences(this)) {
            return;
        }
        addPreferencesFromResource(R.xml.pref_user);

        email = (EditTextPreference) findPreference("email_pref");
        name = (EditTextPreference) findPreference("name_pref");
        surname = (EditTextPreference) findPreference("surname_pref");
        password = (EditTextPreference) findPreference("password_pref");

        email.setText(MyApplication.getUser().getEmail());
        name.setText(MyApplication.getUser().getName());
        surname.setText(MyApplication.getUser().getSurname());

        email.setSummary(MyApplication.getUser().getEmail());
        name.setSummary(MyApplication.getUser().getName());
        surname.setSummary(MyApplication.getUser().getSurname());


        email.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {

            @Override
            public boolean onPreferenceChange(Preference preference, Object newValue) {
                String changedEmail = (String) newValue;
                if (!changedEmail.equals("")) {
                    SettingsTask settingsTask = new SettingsTask("email",changedEmail);
                    settingsTask.execute();
                }
                return true;
            }
        });

        name.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {

            @Override
            public boolean onPreferenceChange(Preference preference, Object newValue) {
                String changedName = (String) newValue;
                if (!changedName.equals("")) {
                    SettingsTask settingsTask = new SettingsTask("name",changedName);
                    settingsTask.execute();
                }
                return true;
            }
        });

        surname.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {

            @Override
            public boolean onPreferenceChange(Preference preference, Object newValue) {
                String changedSurname = (String) newValue;
                if (!changedSurname.equals("")) {
                    SettingsTask settingsTask = new SettingsTask("surname",changedSurname);
                    settingsTask.execute();
                }
                return true;
            }
        });
        password.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
            @Override
            public boolean onPreferenceChange(Preference preference, Object newValue) {
                String changedPassword = (String) newValue;
                if (!changedPassword.equals("") && changedPassword.length()>4) {
                    SettingsTask settingsTask = new SettingsTask("password",changedPassword);
                    settingsTask.execute();
                }
                return true;
            }
        });
    }

    /** {@inheritDoc} */
    @Override
    public boolean onIsMultiPane() {
        return isXLargeTablet(this) && !isSimplePreferences(this);
    }

    /**
     * Helper method to determine if the device has an extra-large screen. For
     * example, 10" tablets are extra-large.
     */
    private static boolean isXLargeTablet(Context context) {
        return (context.getResources().getConfiguration().screenLayout
        & Configuration.SCREENLAYOUT_SIZE_MASK) >= Configuration.SCREENLAYOUT_SIZE_XLARGE;
    }

    /**
     * Determines whether the simplified settings UI should be shown. This is
     * true if this is forced via {@link #ALWAYS_SIMPLE_PREFS}, or the device
     * doesn't have newer APIs like {@link PreferenceFragment}, or the device
     * doesn't have an extra-large screen. In these cases, a single-pane
     * "simplified" settings UI should be shown.
     */
    private static boolean isSimplePreferences(Context context) {
        return ALWAYS_SIMPLE_PREFS
                || Build.VERSION.SDK_INT < Build.VERSION_CODES.HONEYCOMB
                || !isXLargeTablet(context);
    }

    /** {@inheritDoc} */
    @Override
    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    public void onBuildHeaders(List<Header> target) {
        if (!isSimplePreferences(this)) {
            loadHeadersFromResource(R.xml.pref_headers, target);
        }
    }

    /**
     * A preference value change listener that updates the preference's summary
     * to reflect its new value.
     */
    private static Preference.OnPreferenceChangeListener sBindPreferenceSummaryToValueListener = new Preference.OnPreferenceChangeListener() {
        @Override
        public boolean onPreferenceChange(Preference preference, Object value) {
            String stringValue = value.toString();

            if (preference instanceof ListPreference) {
                // For list preferences, look up the correct display value in
                // the preference's 'entries' list.
                ListPreference listPreference = (ListPreference) preference;
                int index = listPreference.findIndexOfValue(stringValue);

                // Set the summary to reflect the new value.
                preference.setSummary(
                        index >= 0
                                ? listPreference.getEntries()[index]
                                : null);

            }  else {
                // For all other preferences, set the summary to the value's
                // simple string representation.
                preference.setSummary(stringValue);
            }
            return true;
        }
    };

    /**
     * Binds a preference's summary to its value. More specifically, when the
     * preference's value is changed, its summary (line of text below the
     * preference title) is updated to reflect the value. The summary is also
     * immediately updated upon calling this method. The exact display format is
     * dependent on the type of preference.
     *
     * @see #sBindPreferenceSummaryToValueListener
     */
    private static void bindPreferenceSummaryToValue(Preference preference) {
        // Set the listener to watch for value changes.
        preference.setOnPreferenceChangeListener(sBindPreferenceSummaryToValueListener);

        // Trigger the listener immediately with the preference's
        // current value.
        sBindPreferenceSummaryToValueListener.onPreferenceChange(preference,
                PreferenceManager
                        .getDefaultSharedPreferences(preference.getContext())
                        .getString(preference.getKey(), ""));
    }

    /**
     * This fragment shows general preferences only. It is used when the
     * activity is showing a two-pane settings UI.
     */
    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    public static class GeneralPreferenceFragment extends PreferenceFragment {
        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            addPreferencesFromResource(R.xml.pref_user);

            // Bind the summaries of EditText/List/Dialog/Ringtone preferences
            // to their values. When their values change, their summaries are
            // updated to reflect the new value, per the Android Design
            // guidelines.
            bindPreferenceSummaryToValue(findPreference("email_pref"));
            bindPreferenceSummaryToValue(findPreference("name_pref"));
            bindPreferenceSummaryToValue(findPreference("surname_pref"));
        }
    }
    public class SettingsTask extends AsyncTask<Void, Void, String> {

        private String change;
        private String theChanged;

        InputStream is = null ;
        String result = "";

        public SettingsTask(String change, String theChanged) {
            this.change = change;
            this.theChanged = theChanged;
        }

        @Override
        protected String doInBackground(Void... params) {

            HttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost("http://titan.cmpe.boun.edu.tr:8080/nutty/user/homesettings/updateUserREST?user_id="+MyApplication.getUser().getId());
            try {
                ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
                nameValuePairs.add(new BasicNameValuePair("changed", change));
                if(change.equals("name")){
                    nameValuePairs.add(new BasicNameValuePair("inputName",theChanged));
                }else if(change.equals("surname")) {
                    nameValuePairs.add(new BasicNameValuePair("inputSurname", theChanged));
                }else if(change.equals("email")) {
                    nameValuePairs.add(new BasicNameValuePair("inputEmail", theChanged));
                }else if(change.equals("password")){
                    nameValuePairs.add(new BasicNameValuePair("inputPassword1", theChanged));
                }
                httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                HttpResponse httpResponse = httpClient.execute(httpPost);
                HttpEntity httpEntity = httpResponse.getEntity();
                //read content
                is =  httpEntity.getContent();
                Thread.sleep(2000);
            }catch (Exception e) {
                Log.e("log_tag", "Error in http connection " + e.toString());
                return e.toString();
            }
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                StringBuilder sb = new StringBuilder();
                String line = "";
                while((line=br.readLine())!=null){
                    sb.append(line+"\n");
                }
                is.close();
                result=sb.toString();
            }catch (Exception e) {
                Log.e("log_tag", "Error converting result " + e.toString());
            }
            return result;
        }

        @Override
        protected void onPostExecute(final String result) {
            try {
                JSONObject json = new JSONObject(result);
                System.out.println(json);
                if(json.getInt("isSuccess")==1){
                    if(change.equals("name")){
                        MyApplication.getUser().setName(theChanged);
                        name.setText(MyApplication.getUser().getName());
                        name.setSummary(MyApplication.getUser().getName());
                    }else if(change.equals("surname")) {
                        MyApplication.getUser().setSurname(theChanged);
                        surname.setText(MyApplication.getUser().getSurname());
                        surname.setSummary(MyApplication.getUser().getSurname());
                    }else if(change.equals("email")) {
                        MyApplication.getUser().setEmail(theChanged);
                        email.setText(MyApplication.getUser().getEmail());
                        email.setSummary(MyApplication.getUser().getEmail());
                    }else if(change.equals("password")){
                        password.setText("");
                    }
                    Toast.makeText(getApplicationContext(),"You have successfully updated your profile!",Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(getApplicationContext(),"Could not update your profile!",Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
                Toast.makeText(getApplicationContext(),"Could not update your profile!",Toast.LENGTH_SHORT).show();
            }
        }
    }
}
