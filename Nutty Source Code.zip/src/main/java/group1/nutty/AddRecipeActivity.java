package group1.nutty;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.dropbox.client2.DropboxAPI;
import com.dropbox.client2.session.AppKeyPair;
import com.dropbox.client2.session.Session;
import com.dropbox.client2.android.*;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

import group1.nutty.adapter.IngAmountAdapter2;
import group1.nutty.group1.nutty.asynctask.GetIngredientsTask;
import group1.nutty.group1.nutty.asynctask.GetMeasureTypeTask;
import group1.nutty.group1.nutty.asynctask.ImgurUploadTask;
import group1.nutty.model.IngredientAmount;

import com.google.gdata.client.*;
import com.google.gdata.client.photos.*;
import com.google.gdata.data.*;
import com.google.gdata.data.extensions.Street;
import com.google.gdata.data.media.*;
import com.google.gdata.data.photos.*;
import com.google.gdata.util.AuthenticationException;
import com.google.gson.Gson;

public class AddRecipeActivity extends Activity {

    private SecureRandom random = new SecureRandom();

    private EditText recipeName;
    private EditText tag;
    private Button addTagButton;
    private Button addIngredient;
    private ImageView recipeImage;
    private Button addPhoto;
    private EditText portion;
    private ArrayList<TextView> tags = new ArrayList<TextView>();
    private EditText description;
    private AutoCompleteTextView ingName;
    private TextView ingAmount;
    private Spinner measureTypes;

    private static final int CAMERA_REQUEST = 1888;

    private ArrayList<IngredientAmount> ingredientItemList = new ArrayList<IngredientAmount>();
    ArrayAdapter<IngredientAmount> adapter;

    Bitmap photo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_recipe);

        final ListView ingredientList = (ListView) findViewById(R.id.ingredientList);
        adapter=new IngAmountAdapter2(this, ingredientItemList);
        ingredientList.setAdapter(adapter);

        recipeImage = (ImageView) findViewById(R.id.recipeImage);

        recipeName = (EditText) findViewById(R.id.recipeName);
        description = (EditText) findViewById(R.id.description);
        portion = (EditText) findViewById(R.id.portion);
        measureTypes = (Spinner) findViewById(R.id.ingUnit);

        addPhoto = (Button) findViewById(R.id.addPhoto);
        addPhoto.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, CAMERA_REQUEST);
            }
        });


        tag = (EditText) findViewById(R.id.tag);
        final LinearLayout tagsLayout = (LinearLayout) findViewById(R.id.tags);
        addTagButton = (Button) findViewById(R.id.addTag);
        addTagButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final TextView tagTextView = new TextView(getApplicationContext());
                tagTextView.setTextAppearance(getApplicationContext(), android.R.style.TextAppearance_Small);
                tagTextView.setText(tag.getText()+"  ");
                tagTextView.setTextColor(Color.BLACK);
                tagTextView.setClickable(true);
                tagTextView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        tagsLayout.removeView(tagTextView);
                        tags.remove(tagTextView);
                    }
                });

                tagsLayout.addView(tagTextView);
                tags.add(tagTextView);
                tag.setText("");
                Toast.makeText(getApplicationContext(),"Tap on the tag to remove", Toast.LENGTH_SHORT).show();
            }
        });

        ingAmount = (TextView) findViewById(R.id.ingAmount);

        ingName = (AutoCompleteTextView) findViewById(R.id.ingName);
        ingName.setTextColor(Color.BLACK);
        ingName.setLinkTextColor(Color.BLACK);
        ingName.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable s) {
                String ingNameStr = ingName.getText().toString();
                if (ingNameStr.length() == 4) {
                    System.out.println(ingName);
                    GetIngredientsTask getIngredients = new GetIngredientsTask(ingNameStr, ingName, getApplicationContext());
                    getIngredients.execute();
                } else {

                }
            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
        });

        ingName.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(), (String) ingName.getAdapter().getItem(position), Toast.LENGTH_LONG).show();
                GetMeasureTypeTask getMeasureTypeTask = new GetMeasureTypeTask((String) ingName.getAdapter().getItem(position), measureTypes, getApplicationContext());
                getMeasureTypeTask.execute();
            }
        });

        addIngredient = (Button) findViewById(R.id.addIngredient);
        addIngredient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                IngredientAmount ingAmountTemp = new IngredientAmount();
                System.out.println(ingName.getText().toString());
                boolean ok = false;
                for(int i=0; i<ingName.getAdapter().getCount(); i++){
                    String temp = (String) ingName.getAdapter().getItem(i);
                    System.out.println(temp);
                    if(temp.equals(ingName.getText().toString())){
                        ok=true;
                    }
                }
                if(ok){
                    try{
                        ingAmountTemp.setIng_name(ingName.getText().toString());
                        ingAmountTemp.setAmount(Integer.parseInt(ingAmount.getText().toString()));
                        ingAmountTemp.setMeas_type((String) measureTypes.getSelectedItem());
                        ingredientItemList.add(ingAmountTemp);
                        adapter.notifyDataSetChanged();
                        setListViewHeightBasedOnChildren(ingredientList);
                        System.out.println(ingredientItemList.size());
                    }catch(Exception e){
                        Toast.makeText(getApplicationContext(),"Enter all the fields!", Toast.LENGTH_LONG).show();
                    }

                }else{
                    Toast.makeText(getApplicationContext(),"Invalid ingredient!", Toast.LENGTH_LONG).show();
                }
                ingName.setText("");
                ingAmount.setText("");
                measureTypes.setAdapter(null);
            }
        });

    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CAMERA_REQUEST && resultCode == RESULT_OK) {
            if(data == null)
                System.out.println("data null donuyor");
            photo = (Bitmap) data.getExtras().get("data");
            try{
                recipeImage.setImageBitmap(photo);
                File file = new File("image");
                FileOutputStream foutStream = new FileOutputStream(file);
                System.out.println(photo.compress(Bitmap.CompressFormat.PNG, 50, foutStream));
            }catch(Exception e){
                System.out.println("foto ekleme sorunu var");
                e.printStackTrace();
            }
        }
    }

    public void done(View view) {
        boolean ok = true;

        String sRecipeName="";
        if(recipeName.getText().length()>0){
            sRecipeName = recipeName.getText().toString();
        }else{
            recipeName.setError("This field can not be empty!");
            ok = false;
        }

        String sDescription="";
        if(description.getText().length()>0){
            sDescription = description.getText().toString();
        }else{
            description.setError("This field can not be empty!");
            ok = false;
        }

        String[] arrTags = new String[tags.size()];
        for(int i=0;i<tags.size();i++){
            arrTags[i] = tags.get(i).getText().toString().trim();
        }

        int iPortion=0;
        if(portion.getText().length()>0){
            iPortion = Integer.parseInt(portion.getText().toString());
        }else{
            portion.setError("This field can not be empty!");
            ok=false;
        }

        long user_id = MyApplication.getUser().getId();

        String[] ingNames = null;
        String[] ingAmounts= null;
        String[] measTypes= null;

        if(adapter.getCount()>0){
            ingNames = new String[adapter.getCount()];
            ingAmounts = new String[adapter.getCount()];
            measTypes = new String[adapter.getCount()];
            for(int i=0; i<adapter.getCount(); i++){
                ingNames[i] = adapter.getItem(i).getIng_name();
                ingAmounts[i] = Double.toString(adapter.getItem(i).getAmount());
                measTypes[i] = adapter.getItem(i).getMeas_type();
            }
        }else{
            Toast.makeText(this, "You have to add at least one ingredient!", Toast.LENGTH_LONG).show();
            ok = false;
        }

//        String recipeName;
//        String description;
//        String link;
        Gson gson = new Gson();
        String ingredientz = gson.toJson(ingNames, String[].class);
        String amountz = gson.toJson(ingAmounts, String[].class);
        String tagz = gson.toJson(arrTags, String[].class);
        if(arrTags.length <= 0){
            tagz = "emptyTags";
        }
        String measTypez = gson.toJson(measTypes, String[].class);
        String[] link = {"http://bigmexicandinner.com/wp-content/uploads/2009/04/green-apple.jpg"};

//        int portion;
//        long user_id;



        if(ok){

            ImgurUploadTask imgurUploadTask = new ImgurUploadTask(photo);
            try {
                String photoLink = imgurUploadTask.execute().get();
                link[0]=photoLink;
            } catch (Exception e) {
                e.printStackTrace();
            }
            String linkz = gson.toJson(link, String[].class);
            System.out.println(sRecipeName+"\n"+sDescription+"\n"+linkz+"\n"+ingredientz+"\n"+amountz+"\n"+tagz+"\n"+measTypez+"\n"+iPortion+"\n"+user_id);
            AddRecipeTask addRecipeTask = new AddRecipeTask(sRecipeName, sDescription, iPortion, linkz, ingredientz, amountz, measTypez, user_id, tagz);
            addRecipeTask.execute();
            Intent intent = new Intent(this,ProfileActivity.class);
            startActivity(intent);
            finish();
        }


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            Intent allSetting = new Intent(getApplicationContext(), AllSettings.class);
            startActivity(allSetting);
            return true;
        }
        else if(id == R.id.action_logout){
            MyApplication myApplication = (MyApplication) getApplicationContext();
            myApplication.reset();
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            return true;
        }else if(id == R.id.action_profile){
            Intent intent = new Intent(this, ProfileActivity.class);
            startActivity(intent);
            return true;
        }
        else if(id == R.id.search){
            Intent intent = new Intent(this, SearchActivity.class);
            startActivity(intent);
            return true;
        }else if(id == R.id.home){
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public static void setListViewHeightBasedOnChildren(ListView listView) {
        ListAdapter listAdapter = listView.getAdapter();
        if (listAdapter == null)
            return;

        int desiredWidth = View.MeasureSpec.makeMeasureSpec(listView.getWidth(), View.MeasureSpec.UNSPECIFIED);
        int totalHeight = 0;
        View view = null;
        for (int i = 0; i < listAdapter.getCount(); i++) {
            view = listAdapter.getView(i, view, listView);
            if (i == 0)
                view.setLayoutParams(new ViewGroup.LayoutParams(desiredWidth, ViewGroup.LayoutParams.WRAP_CONTENT));

            view.measure(desiredWidth, View.MeasureSpec.UNSPECIFIED);
            totalHeight += view.getMeasuredHeight();
        }
        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight + (listView.getDividerHeight() * (listAdapter.getCount() - 1));
        listView.setLayoutParams(params);
        listView.requestLayout();
    }

    public class AddRecipeTask extends AsyncTask<Void, Void, String> {

        String recipeName;
        String description;
        String link;
        String ingredientz;
        String amountz;
        String tagz;
        String measTypez;
        int portion;
        long user_id;
        InputStream is = null ;
        String result = "";

        AddRecipeTask(String recipeName, String description, int portion, String link, String ingredientz, String amountz, String measTypez, long user_id, String tagz) {
            this.recipeName = recipeName;
            this.description = description;
            this.portion = portion;
            this.link=link;
            this.ingredientz=ingredientz;
            this.amountz=amountz;
            this.user_id=user_id;
            this.tagz=tagz;
            this.measTypez = measTypez;
        }

        @Override
        protected String doInBackground(Void... params) {

            HttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost("http://titan.cmpe.boun.edu.tr:8080/nutty/addRecipeREST?portion="+portion+"&user_id="+user_id);
            try {
                ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(7);
                nameValuePairs.add(new BasicNameValuePair("recipeName", recipeName));
                nameValuePairs.add(new BasicNameValuePair("description",description));
                nameValuePairs.add(new BasicNameValuePair("link[]",link));
                nameValuePairs.add(new BasicNameValuePair("ingredient[]",ingredientz));
                nameValuePairs.add(new BasicNameValuePair("amount[]",amountz));
                if(!tagz.equals("emptyTags")){
                    nameValuePairs.add(new BasicNameValuePair("tag[]",tagz));
                }
                nameValuePairs.add(new BasicNameValuePair("measType[]",measTypez));
                httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                HttpResponse httpResponse = httpClient.execute(httpPost);
                HttpEntity httpEntity = httpResponse.getEntity();
                //read content
                is =  httpEntity.getContent();
                Thread.sleep(2000);
            }catch (Exception e) {
                Log.e("log_tag", "Error in http connection " + e.toString());
                return e.toString();
            }
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                StringBuilder sb = new StringBuilder();
                String line = "";
                while((line=br.readLine())!=null){
                    sb.append(line+"\n");
                }
                is.close();
                result=sb.toString();
            }catch (Exception e) {
                Log.e("log_tag", "Error converting result " + e.toString());
            }
            return result;
        }

        @Override
        protected void onPostExecute(final String result) {
            System.out.println(result);
        }

        @Override
        protected void onCancelled() {

        }
    }

    public class UploadToDropbox extends AsyncTask<Void, Void, String>{

        private String APP_KEY = "3w5na2l3vyhyetr";
        private String APP_SECRET = "33undpctdfm5r17";
        private Session.AccessType ACCESS_TYPE = Session.AccessType.APP_FOLDER;
        private DropboxAPI<AndroidAuthSession> mDBApi;

        UploadToDropbox(){
            // And later in some initialization function:
            AppKeyPair appKeys = new AppKeyPair(APP_KEY, APP_SECRET);
            AndroidAuthSession session = new AndroidAuthSession(appKeys, ACCESS_TYPE);
            mDBApi = new DropboxAPI<AndroidAuthSession>(session);
        }

        @Override
        protected String doInBackground(Void... params) {
            return null;
        }
    }
}
