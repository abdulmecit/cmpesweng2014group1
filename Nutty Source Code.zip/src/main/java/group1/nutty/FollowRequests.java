package group1.nutty;

import android.app.Activity;
import android.os.AsyncTask;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import group1.nutty.group1.nutty.asynctask.GetFollowers;


public class FollowRequests extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_follow_requests);

        ListView followRequests = (ListView) findViewById(R.id.followRequests);
        GetFollowers getFollowers = new GetFollowers(getApplicationContext(), MyApplication.getUser().getId(), followRequests);
        getFollowers.execute();

    }
}
