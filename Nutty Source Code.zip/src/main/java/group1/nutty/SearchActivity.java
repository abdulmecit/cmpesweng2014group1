package group1.nutty;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Locale;

import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.v13.app.FragmentPagerAdapter;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import group1.nutty.adapter.BasicSearchListAdapter;
import group1.nutty.adapter.UserListAdapter;
import group1.nutty.group1.nutty.asynctask.GetIngredientsTask;
import group1.nutty.model.Recipe;
import group1.nutty.model.User;

public class SearchActivity extends Activity implements ActionBar.TabListener {

    /**
     * The {@link android.support.v4.view.PagerAdapter} that will provide
     * fragments for each of the sections. We use a
     * {@link FragmentPagerAdapter} derivative, which will keep every
     * loaded fragment in memory. If this becomes too memory intensive, it
     * may be best to switch to a
     * {@link android.support.v13.app.FragmentStatePagerAdapter}.
     */
    SectionsPagerAdapter mSectionsPagerAdapter;

    /**
     * The {@link ViewPager} that will host the section contents.
     */
    static ViewPager mViewPager;

    static EditText txtSearch;

    static ListView userSearchList;
    static ArrayList<User> users = new ArrayList<User>();
    static ArrayAdapter<User> adapter;

    static ListView basicSearchList;
    static  ArrayList<Recipe> recipes = new ArrayList<Recipe>();
    static ArrayAdapter<Recipe> recipeAdapter;

    static ListView advancedSearchList;
    static ArrayAdapter<String> advancedSearchAdapter;
    static ArrayList<String> ingNames;

    boolean isUser;

    static Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        ingNames = new ArrayList<String>();

        context = this;
        if(MyApplication.getUser()==null){
            isUser = false;
        }else{
            isUser = true;
        }

        // Set up the action bar.
        final ActionBar actionBar = getActionBar();
        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);

        // Create the adapter that will return a fragment for each of the three
        // primary sections of the activity.
        mSectionsPagerAdapter = new SectionsPagerAdapter(getFragmentManager());

        // Set up the ViewPager with the sections adapter.
        mViewPager = (ViewPager) findViewById(R.id.pager);
        mViewPager.setAdapter(mSectionsPagerAdapter);

        // When swiping between different sections, select the corresponding
        // tab. We can also use ActionBar.Tab#select() to do this if we have
        // a reference to the Tab.
        mViewPager.setOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
            @Override
            public void onPageSelected(int position) {
                actionBar.setSelectedNavigationItem(position);
            }
        });

        // For each of the sections in the app, add a tab to the action bar.
        for (int i = 0; i < mSectionsPagerAdapter.getCount(); i++) {
            // Create a tab with text corresponding to the page title defined by
            // the adapter. Also specify this Activity object, which implements
            // the TabListener interface, as the callback (listener) for when
            // this tab is selected.
            actionBar.addTab(
                    actionBar.newTab()
                            .setText(mSectionsPagerAdapter.getPageTitle(i))
                            .setTabListener(this));
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        /** Get the action view of the menu item whose id is search */
        View v = (View) menu.findItem(R.id.search).getActionView();

        /** Get the edit text from the action view */
        txtSearch = ( EditText ) v.findViewById(R.id.txt_search);
//        txtSearch.setImeActionLabel("Search",1);


        /** Setting an action listener */
        txtSearch.setOnEditorActionListener(new TextView.OnEditorActionListener() {

            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                SearchTask searchTask;
                if(mViewPager.getCurrentItem()==0){
                    searchTask = new SearchTask(v.getText().toString(),"recipe");
                }else{
                    searchTask = new SearchTask(v.getText().toString(),"");
                }
                searchTask.execute();

                return false;
            }
        });

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            if(isUser){
                Intent allSetting = new Intent(getApplicationContext(), AllSettings.class);
                startActivity(allSetting);
            }else{
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
            }

            return true;
        }else if(id == R.id.action_logout){
            MyApplication myApplication = (MyApplication) getApplicationContext();
            myApplication.reset();
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            return true;
        }else if(id == R.id.action_profile){
            if(isUser){
                Intent intent = new Intent(this, ProfileActivity.class);
                startActivity(intent);
            }else{
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
            }
            return true;
        }else if(id == R.id.home){
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onTabSelected(ActionBar.Tab tab, FragmentTransaction fragmentTransaction) {
        // When the given tab is selected, switch to the corresponding page in
        // the ViewPager.
        mViewPager.setCurrentItem(tab.getPosition());
    }

    @Override
    public void onTabUnselected(ActionBar.Tab tab, FragmentTransaction fragmentTransaction) {
    }

    @Override
    public void onTabReselected(ActionBar.Tab tab, FragmentTransaction fragmentTransaction) {
    }

    /**
     * A {@link FragmentPagerAdapter} that returns a fragment corresponding to
     * one of the sections/tabs/pages.
     */
    public class SectionsPagerAdapter extends FragmentPagerAdapter {

        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            // getItem is called to instantiate the fragment for the given page.
            // Return a PlaceholderFragment (defined as a static inner class below).

            if(position==0){
                return BasicSearchFragment.newInstance(position + 1);
            }else if(position==1){
                return UserSearchFragment.newInstance(position + 1);
            }else if(position==2){
                return AdvancedSearchFragment.newInstance(position + 1);
            }else{
                return BasicSearchFragment.newInstance(position + 1);
            }
        }

        @Override
        public int getCount() {
            // Show 3 total pages
            if(isUser){
                return 3;
            }else{
                return 2;
            }
        }

        @Override
        public CharSequence getPageTitle(int position) {
            Locale l = Locale.getDefault();
            switch (position) {
                case 0:
                    return "RECIPE".toUpperCase(l);
                case 1:
                    return getString(R.string.title_user_search).toUpperCase(l);
                case 2:
                    return "ADVANCED".toUpperCase(l);
            }
            return null;
        }
    }

    public static class AdvancedSearchFragment extends Fragment {
        /**
         * The fragment argument representing the section number for this
         * fragment.
         */
        private static final String ARG_SECTION_NUMBER = "section_number";

        /**
         * Returns a new instance of this fragment for the given section
         * number.
         */
        public static AdvancedSearchFragment newInstance(int sectionNumber) {
            AdvancedSearchFragment fragment = new AdvancedSearchFragment();
            Bundle args = new Bundle();
            args.putInt(ARG_SECTION_NUMBER, sectionNumber);
            fragment.setArguments(args);
            return fragment;
        }

        public AdvancedSearchFragment() {
        }

        @Override
        public View onCreateView(LayoutInflater inflater, final ViewGroup container,
                                 Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.fragment_advanced_search, container, false);
            advancedSearchList = (ListView) rootView.findViewById(R.id.ingredients);
            advancedSearchAdapter = new ArrayAdapter<String>(context, android.R.layout.simple_list_item_1, ingNames);
            advancedSearchList.setAdapter(advancedSearchAdapter);

            //final ArrayList<String> tagsArray = new ArrayList<String>();

            final EditText tagInput = (EditText) rootView.findViewById(R.id.tag);
            /*Button addTag = (Button) rootView.findViewById(R.id.addTag);
            final LinearLayout tags = (LinearLayout) rootView.findViewById(R.id.tags);
            addTag.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final String tagString = tagInput.getText().toString() + "  ";
                    final TextView newTag = new TextView(context);
                    newTag.setText(tagString);
                    newTag.setTextColor(Color.BLACK);
                    newTag.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            tags.removeView(newTag);
                            tagsArray.remove(tagString);
                        }
                    });
                    tags.addView(newTag);
                    tagsArray.add(tagString);
                    tagInput.setText("");
                    Toast.makeText(context,"Tap tag to remove!",Toast.LENGTH_SHORT).show();
                }
            });
*/
            final CheckBox considerPref = (CheckBox) rootView.findViewById(R.id.considerPref);
            final CheckBox considerEaten = (CheckBox) rootView.findViewById(R.id.considerEaten);
            final CheckBox useTags = (CheckBox) rootView.findViewById(R.id.useTags);

            final EditText minCal = (EditText) rootView.findViewById(R.id.minCal);
            final EditText maxCal = (EditText) rootView.findViewById(R.id.maxCal);

            final AutoCompleteTextView mustHaveIngredient = (AutoCompleteTextView) rootView.findViewById(R.id.mustHaveIngredient);
            mustHaveIngredient.addTextChangedListener(new TextWatcher() {
                public void afterTextChanged(Editable s) {
                    String ingNameStr = mustHaveIngredient.getText().toString();
                    if (ingNameStr.length() == 4) {
                        System.out.println(mustHaveIngredient);
                        GetIngredientsTask getIngredients = new GetIngredientsTask(ingNameStr, mustHaveIngredient, context);
                        getIngredients.execute();
                    } else {

                    }
                }

                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }

                public void onTextChanged(CharSequence s, int start, int before, int count) {
                }
            });

            Button addIngredient = (Button) rootView.findViewById(R.id.addIng);
            addIngredient.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String ingName = mustHaveIngredient.getText().toString();
                    boolean ok = false;
                    for(int i=0; i<mustHaveIngredient.getAdapter().getCount(); i++){
                        String temp = (String) mustHaveIngredient.getAdapter().getItem(i);
                        if(temp.equals(ingName)){
                            ok=true;
                        }
                    }
                    if(ok){
                        ingNames.add(ingName);
                        advancedSearchAdapter.notifyDataSetChanged();
                        Toast.makeText(context,"Tap ingredient to remove!",Toast.LENGTH_SHORT).show();
                    }else{
                        Toast.makeText(context,"Invalid ingredient!", Toast.LENGTH_LONG).show();
                    }

                }
            });
            advancedSearchList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    advancedSearchAdapter.remove(advancedSearchAdapter.getItem(position));
                }
            });

            Button searchButton = (Button) rootView.findViewById(R.id.searchButton);
            searchButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    System.out.println(tagInput.getText().toString());
                    System.out.println(minCal.getText().toString());
                    System.out.println(maxCal.getText().toString());
                    System.out.println(considerPref.isChecked());
                    System.out.println(considerEaten.isChecked());
                    System.out.println(useTags.isChecked());
                    ArrayList<String> arr = new ArrayList<String>();
                    for(int i=0; i<advancedSearchList.getAdapter().getCount(); i++){
                        System.out.print(advancedSearchList.getAdapter().getItem(i).toString()+"\t");
                        arr.add(advancedSearchList.getAdapter().getItem(i).toString());
                    }
                    System.out.println();

                    AdvancedSearchTask advancedSearchTask = new AdvancedSearchTask(tagInput.getText().toString(), minCal.getText().toString(), maxCal.getText().toString(), considerPref.isChecked(), considerEaten.isChecked(), useTags.isChecked(), arr);
                    advancedSearchTask.execute();
                    mViewPager.setCurrentItem(0);
                }
            });

            return rootView;
        }
    }

    /**
     * A placeholder fragment containing a simple view.
     */
    public static class BasicSearchFragment extends Fragment {
        /**
         * The fragment argument representing the section number for this
         * fragment.
         */
        private static final String ARG_SECTION_NUMBER = "section_number";

        /**
         * Returns a new instance of this fragment for the given section
         * number.
         */
        public static BasicSearchFragment newInstance(int sectionNumber) {
            BasicSearchFragment fragment = new BasicSearchFragment();
            Bundle args = new Bundle();
            args.putInt(ARG_SECTION_NUMBER, sectionNumber);
            fragment.setArguments(args);
            return fragment;
        }

        public BasicSearchFragment() {

        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.fragment_basic_search, container, false);
            basicSearchList = (ListView) rootView.findViewById(R.id.basicSearchList);
            return rootView;
        }
    }

    public static class UserSearchFragment extends Fragment {
        /**
         * The fragment argument representing the section number for this
         * fragment.
         */
        private static final String ARG_SECTION_NUMBER = "section_number";

        /**
         * Returns a new instance of this fragment for the given section
         * number.
         */
        public static UserSearchFragment newInstance(int sectionNumber) {
            UserSearchFragment fragment = new UserSearchFragment();
            Bundle args = new Bundle();
            args.putInt(ARG_SECTION_NUMBER, sectionNumber);
            fragment.setArguments(args);
            return fragment;
        }

        public UserSearchFragment() {
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.fragment_user_search, container, false);
            userSearchList = (ListView) rootView.findViewById(R.id.userSearchList);

            return rootView;
        }
    }

    public static class AdvancedSearchTask extends AsyncTask<Void, Void, String> {

        String search;
        String minCal;
        String maxCal;
        boolean considerPref;
        boolean considerEaten;
        boolean useTags;
        String[] ingredients;
        String ingredientz;

        InputStream is = null ;
        String result = "";

        AdvancedSearchTask(String search, String minCal, String maxCal, boolean considerPref, boolean considerEaten, boolean useTags, ArrayList<String> ingredients) {
            this.search = search;
            this.maxCal = maxCal;
            this.minCal = minCal;
            this.considerEaten = considerEaten;
            this.considerPref = considerPref;
            this.useTags = useTags;
            this.ingredients = new String[ingredients.size()];
            for(int i=0; i<ingredients.size(); i++){
                this.ingredients[i] = ingredients.get(i);
            }
            Gson gson = new Gson();
            this.ingredientz = gson.toJson(this.ingredients);
        }

        @Override
        protected void onPreExecute(){
            recipes = new ArrayList<Recipe>();
            users = new ArrayList<User>();
        }

        @Override
        protected String doInBackground(Void... params) {

            HttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost("http://titan.cmpe.boun.edu.tr:8080/nutty/advancedSearchResults?user_id="+MyApplication.getUser().getId()+"&enableEaten="+considerEaten+"&disableSemantic="+useTags+"&enableFoodSelection="+considerPref+"&calorieIntervalLow="+minCal+"&calorieIntervalHigh"+maxCal);
            try {
                ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
                nameValuePairs.add(new BasicNameValuePair("search", search));
                nameValuePairs.add(new BasicNameValuePair("mustHaveIngredientz", ingredientz));
                httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                HttpResponse httpResponse = httpClient.execute(httpPost);
                HttpEntity httpEntity = httpResponse.getEntity();
                //read content
                is =  httpEntity.getContent();
                Thread.sleep(2000);
            }catch (Exception e) {
                Log.e("log_tag", "Error in http connection " + e.toString());
                return e.toString();
            }
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                StringBuilder sb = new StringBuilder();
                String line = "";
                while((line=br.readLine())!=null){
                    sb.append(line+"\n");
                }
                is.close();
                result=sb.toString();
            }catch (Exception e) {
                Log.e("log_tag", "Error converting result " + e.toString());
            }
            return result;
        }

        @Override
        protected void onPostExecute(final String result) {
            System.out.println(result);
            try {
                JSONArray recipeArray = new JSONArray(result);
                if(recipeArray.length()>0){
                    for(int i=0;i<recipeArray.length();i++) {
                        JSONObject recipeData = recipeArray.getJSONObject(i);
                        Recipe recipe = new Recipe();
                        recipe.setName(recipeData.getString("name"));
                        recipe.setRecipe_id(Integer.parseInt(recipeData.getString("id")));
                        recipe.setPhoto(recipeData.getString("photoUrl"));
                        recipes.add(recipe);
                    }
                }else{
                    Toast.makeText(context, "No recipe found!", Toast.LENGTH_SHORT).show();
                }
                recipeAdapter = new BasicSearchListAdapter(context, recipes);
                basicSearchList.setAdapter(recipeAdapter);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        @Override
        protected void onCancelled() {

        }
    }

    public class SearchTask extends AsyncTask<Void, Void, String> {

        String search;
        String searchOption;
        String link;

        InputStream is = null ;
        String result = "";

        SearchTask(String search, String searchOption) {
            this.search = search;
            this.searchOption = searchOption;
            if(searchOption.equalsIgnoreCase("recipe")){
                this.link = "http://titan.cmpe.boun.edu.tr:8080/nutty/basicSearchREST3";
            }else{
                this.link = "http://titan.cmpe.boun.edu.tr:8080/nutty/basicSearchREST";
            }
        }

        @Override
        protected void onPreExecute(){
            recipes = new ArrayList<Recipe>();
            users = new ArrayList<User>();
        }

        @Override
        protected String doInBackground(Void... params) {

            HttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(link);
            try {
                ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
                nameValuePairs.add(new BasicNameValuePair("search", search));
                nameValuePairs.add(new BasicNameValuePair("searchOption",searchOption));
                httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                HttpResponse httpResponse = httpClient.execute(httpPost);
                HttpEntity httpEntity = httpResponse.getEntity();
                //read content
                is =  httpEntity.getContent();
                Thread.sleep(2000);
            }catch (Exception e) {
                Log.e("log_tag", "Error in http connection " + e.toString());
                return e.toString();
            }
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                StringBuilder sb = new StringBuilder();
                String line = "";
                while((line=br.readLine())!=null){
                    sb.append(line+"\n");
                }
                is.close();
                result=sb.toString();
            }catch (Exception e) {
                Log.e("log_tag", "Error converting result " + e.toString());
            }
            return result;
        }

        @Override
        protected void onPostExecute(final String result) {
            System.out.println(result);
            if(searchOption.equalsIgnoreCase("recipe")){
                try {
                    JSONArray recipeArray = new JSONArray(result);
                    if(recipeArray.length()>0){
                        for(int i=0;i<recipeArray.length();i++) {
                            JSONObject recipeData = recipeArray.getJSONObject(i);
                            Recipe recipe = new Recipe();
                            recipe.setName(recipeData.getString("name"));
                            recipe.setRecipe_id(Integer.parseInt(recipeData.getString("id")));
                            recipe.setPhoto(recipeData.getString("photoUrl"));
                            recipes.add(recipe);
                        }
                    }else{
                        Toast.makeText(getBaseContext(), "No recipe found!", Toast.LENGTH_SHORT).show();
                    }
                    recipeAdapter = new BasicSearchListAdapter(getApplicationContext(), recipes);
                    basicSearchList.setAdapter(recipeAdapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }else{
                try {
                    JSONArray usersArray = new JSONArray(result);
                    if(usersArray.length()>0){
                        for(int i=0;i<usersArray.length();i++) {
                            JSONObject userData = usersArray.getJSONObject(i);
                            User user = new User(userData.getInt("id"), userData.getString("email"), userData.getString("name"), userData.getString("surname"), userData.getString("birthday"), userData.getString("gender"), userData.getString("isBanned"), userData.getString("photo"));
                            users.add(user);
                        }
                    }else{
                        Toast.makeText(getBaseContext(), "No user found!", Toast.LENGTH_SHORT).show();
                    }
                    adapter = new UserListAdapter(getApplicationContext(), users);
                    userSearchList.setAdapter(adapter);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

        }

        @Override
        protected void onCancelled() {

        }
    }

}
