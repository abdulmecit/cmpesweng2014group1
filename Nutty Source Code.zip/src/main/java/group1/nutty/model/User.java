package group1.nutty.model;

import java.util.ArrayList;

import group1.nutty.model.Ingredient;


public class User {
    private int id;
    private String email;
    private String name;
    private String surname;
    private String date;
    private String gender;
    private boolean isBanned;
    private String photo;
    private ArrayList<String> intoleranceAndAllergies = new ArrayList<String>();
    private ArrayList<String> diseases = new ArrayList<String>();
    private ArrayList<Ingredient> nonPreferredIngredient = new ArrayList<Ingredient>();
    private ArrayList<Integer> ownedRecipesIDs = new ArrayList<Integer>();
    String badge;

    public User(){

    }

    public User(int id, String email, String name, String surname, String date, String gender, String isBanned, String photo) {
        this.id = id;
        this.email = email;
        this.name = name;
        this.surname = surname;
        this.date = date;
        if(gender.equalsIgnoreCase("0")){
            this.gender = "male";
        }else{
            this.gender = "female";
        }
        if(isBanned.equalsIgnoreCase("0")){
            this.isBanned = false;
        }else{
            this.isBanned = true;
        }
        this.photo = photo;
    }

    public int getId() {
        return id;
    }

    public String getEmail() {
        return email;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public String getDate() {
        return date;
    }

    public String getGender() {
        return gender;
    }

    public boolean isBanned() {
        return isBanned;
    }

    public String getPhoto() {
        return photo;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setBanned(boolean isBanned) {
        this.isBanned = isBanned;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public ArrayList<String> getIntoleranceAndAllergies(){
        return intoleranceAndAllergies;
    }

    public void addIntoleranceAndAllergies(String selection){
        this.intoleranceAndAllergies.add(selection);
    }

    public ArrayList<String> getDiseases() {
        return diseases;
    }

    public void addDiseases(String selection){
        this.diseases.add(selection);
    }

    public ArrayList<Ingredient> getNonPreferredIngredient() {
        return nonPreferredIngredient;
    }

    public void addNonPreferredIngredient(Ingredient ingredient){
        this.nonPreferredIngredient.add(ingredient);
    }
    public ArrayList<Integer> getOwnedRecipesIDs(){
        return ownedRecipesIDs;
    }
    public void addOwnedRecipeID(int recipeID){
        this.ownedRecipesIDs.add(recipeID);
    }

    public boolean recipeIsFromUser(int theRecipeID){
        for(int recipeID : ownedRecipesIDs){
            if(theRecipeID == recipeID){
                return true;
            }
        }
        return false;
    }

    public String getBadge() {
        return badge;
    }

    public void setBadge(String badge) {
        this.badge = badge;
    }
}
