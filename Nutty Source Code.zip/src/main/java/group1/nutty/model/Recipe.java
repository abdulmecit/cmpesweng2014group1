package group1.nutty.model;

import org.json.JSONException;
import org.json.JSONObject;

import java.sql.Timestamp;
import java.util.Date;

/**
 * Created by gokhanonalan on 02/12/14.
 */
public class Recipe {

    private int recipe_id;
    private String name;
    private String description;
    private int portion;
    private Timestamp updatedDate;
    private Timestamp createdDate;
    private double total_calorie;
    private double total_fat;
    private double total_protein;
    private double total_carbohydrate;
    private String photo;

    public Recipe() {
        super();
    }

    public Recipe(int recipe_id, String name, String description, int portion,
                  Timestamp date,double total_calorie) {
        super();
        this.setRecipe_id(recipe_id);
        this.name = name;
        this.description = description;
        this.portion = portion;
        this.createdDate = date;
        this.setTotal_calorie(total_calorie);
    }
    public Recipe(JSONObject json){
        try {
            this.recipe_id = json.getInt("recipe_id");
            this.name = json.getString("name");
            this.description = json.getString("description");
            this.portion = json.getInt("portion");
            Long createdDateArray = json.getLong("createdDate");
            Long updatedDateArray = json.getLong("updatedDate");
            this.createdDate = new Timestamp(createdDateArray);
            this.updatedDate = new Timestamp(updatedDateArray);
            this.total_calorie = json.getJSONObject("nutrition_info").getDouble("total_calorie");
            this.total_fat = json.getJSONObject("nutrition_info").getDouble("total_fat");
            this.total_protein = json.getJSONObject("nutrition_info").getDouble("total_protein");
            this.total_carbohydrate = json.getJSONObject("nutrition_info").getDouble("total_carbohydrate");
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    public int getRecipe_id() {
        return recipe_id;
    }

    public void setRecipe_id(int recipe_id) {
        this.recipe_id = recipe_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    public int getPortion() {
        return portion;
    }
    public void setPortion(int portion) {
        this.portion = portion;
    }
    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Timestamp date) {
        this.createdDate = date;
    }
    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Timestamp date) {
        this.updatedDate = date;
    }

    public double getTotal_calorie() {
        return total_calorie;
    }

    public void setTotal_calorie(double total_calorie) {
        this.total_calorie = total_calorie;
    }

    public String getPhoto(){
        return photo;
    }

    public void setPhoto(String photo){
        this.photo = photo;
    }

    public double getTotal_fat() {
        return total_fat;
    }

    public double getTotal_protein() {
        return total_protein;
    }

    public double getTotal_carbohydrate() {
        return total_carbohydrate;
    }
}
