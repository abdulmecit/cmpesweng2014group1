package group1.nutty.model;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Comment {
    private String commenter;
    private int comment_id;
    private String text;
    private int user_id;
    private int recipe_id;
    private int comment_likes;
    private ArrayList<Integer> likerIDs = new ArrayList<Integer>();

    public Comment() {
        super();
    }
    public Comment(int comment_id, String text){
        super();
        this.setComment_id(comment_id);
        this.setText(text);
    }
    public Comment(JSONObject json, String commenter, JSONArray commenLikerIDs){
        try {
            this.comment_id = json.getInt("comment_id");
            this.text = json.getString("text");
            this.user_id = json.getInt("user_id");
            this.recipe_id = json.getInt("recipe_id");
            this.commenter = commenter;
            this.comment_likes = commenLikerIDs.length();
            for(int i=0; i<commenLikerIDs.length(); i++){
                if(commenLikerIDs.getInt(i) != 0){
                    likerIDs.add(commenLikerIDs.getInt(i));
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    public Comment(JSONObject json, String commenter){
        try {
            this.comment_id = json.getInt("comment_id");
            this.text = json.getString("text");
            this.user_id = json.getInt("user_id");
            this.recipe_id = json.getInt("recipe_id");
            this.commenter = commenter;
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    public int getComment_id() {
        return comment_id;
    }
    public void setComment_id(int comment_id) {
        this.comment_id = comment_id;
    }
    public String getText() {
        return text;
    }
    public void setText(String text) {
        this.text = text;
    }
    public long getUser_id() {
        return user_id;
    }
    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }
    public int getRecipe_id() {
        return recipe_id;
    }
    public void setRecipe_id(int recipe_id) {
        this.recipe_id = recipe_id;
    }
    public String getCommenter() {
        return commenter;
    }
    public void setCommenter(String commenter) {
        this.commenter = commenter;
    }
    public int getCommentLikes(){
        return comment_likes;
    }
    public ArrayList<Integer> getLikerIDs() {
        return likerIDs;
    }
    public int getComment_likes() {
        return comment_likes;
    }
}
