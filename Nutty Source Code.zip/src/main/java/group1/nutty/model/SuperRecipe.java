package group1.nutty.model;

import java.util.ArrayList;

public class SuperRecipe{

    private Recipe recipe;
    private ArrayList<IngredientAmount> ingredientAmounts = new ArrayList<IngredientAmount>();
    private ArrayList<Comment> comments = new ArrayList<Comment>();
    private int noOfLikes;
    private int noOfEats;
    private double avgHealthRate;
    private double avgCostRate;
    private double avgTasteRate;
    private double avgEaseRate;
    private String photoUrl;
    private String owner;
    private Recipe parent;
    private ArrayList<Recipe> children = new ArrayList<Recipe>();
    private ArrayList<Tag> tags = new ArrayList<Tag>();

    public SuperRecipe() {
        super();
    }

    public Recipe getRecipe() {
        return recipe;
    }

    public void setRecipe(Recipe recipe) {
        this.recipe = recipe;
    }

    public ArrayList<IngredientAmount> getIngredientAmounts() {
        return ingredientAmounts;
    }

    public void addIngredientAmounts(IngredientAmount ingredientAmounts) {
        this.ingredientAmounts.add(ingredientAmounts);
    }

    public ArrayList<Comment> getComments() {
        return comments;
    }

    public void addComment(Comment comment) {
        this.comments.add(comment);
    }

    public int getNoOfLikes() {
        return noOfLikes;
    }

    public void setNoOfLikes(int noOfLikes) {
        this.noOfLikes = noOfLikes;
    }

    public int getNoOfEats() {
        return noOfEats;
    }

    public void setNoOfEats(int noOfEats) {
        this.noOfEats = noOfEats;
    }

    public double getAvgHealthRate() {
        return avgHealthRate;
    }

    public void setAvgHealthRate(double avgHealthRate) {
        this.avgHealthRate = avgHealthRate;
    }

    public double getAvgCostRate() {
        return avgCostRate;
    }

    public void setAvgCostRate(double avgCostRate) {
        this.avgCostRate = avgCostRate;
    }

    public double getAvgTasteRate() {
        return avgTasteRate;
    }

    public void setAvgTasteRate(double avgTasteRate) {
        this.avgTasteRate = avgTasteRate;
    }

    public double getAvgEaseRate() {
        return avgEaseRate;
    }

    public void setAvgEaseRate(double avgEaseRate) {
        this.avgEaseRate = avgEaseRate;
    }

    public String getPhotoUrl() {
        return photoUrl;
    }

    public void setPhotoUrl(String photoUrl) {
        this.photoUrl = photoUrl;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public Recipe getParent() {
        return parent;
    }

    public void setParent(Recipe parent) {
        this.parent = parent;
    }

    public ArrayList<Recipe> getChildren() {
        return children;
    }

    public void addChild(Recipe child) {
        this.children.add(child);
    }

    public ArrayList<Tag> getTags() {
        return tags;
    }

    public void addTag(Tag tag) {
        this.tags.add(tag);
    }

    public void setIngredientAmounts(ArrayList<IngredientAmount> ingredientAmounts) {
        this.ingredientAmounts = ingredientAmounts;
    }

    public void setComments(ArrayList<Comment> comments) {
        this.comments = comments;
    }

    public void setChildren(ArrayList<Recipe> children) {
        this.children = children;
    }

    public void setTags(ArrayList<Tag> tags) {
        this.tags = tags;
    }
}
