var searchData=
[
  ['ownsrecipe',['OwnsRecipe',['../classcmpesweng2014_1_1group1_1_1nutty_1_1model_1_1_owns_recipe.html#ab4a7ed273c79b4a3c3a0b9dcc1e87352',1,'cmpesweng2014.group1.nutty.model.OwnsRecipe.OwnsRecipe()'],['../classcmpesweng2014_1_1group1_1_1nutty_1_1model_1_1_owns_recipe.html#a292f52ac7b4e3c0578e1fe8ef0e5da26',1,'cmpesweng2014.group1.nutty.model.OwnsRecipe.OwnsRecipe(Long user_id, int recipe_id)']]]
];
