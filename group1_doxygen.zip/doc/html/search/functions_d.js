var searchData=
[
  ['parseamount',['parseAmount',['../classcmpesweng2014_1_1group1_1_1nutty_1_1service_1_1_recipe_service.html#ab34b35d33ea4bebf52a025238106a63a',1,'cmpesweng2014::group1::nutty::service::RecipeService']]],
  ['privacyoptions',['PrivacyOptions',['../classcmpesweng2014_1_1group1_1_1nutty_1_1model_1_1_privacy_options.html#a298b89466325050456bed3ed500df88c',1,'cmpesweng2014.group1.nutty.model.PrivacyOptions.PrivacyOptions()'],['../classcmpesweng2014_1_1group1_1_1nutty_1_1model_1_1_privacy_options.html#a25e39a7375d3b70a497ddc535ac7edc8',1,'cmpesweng2014.group1.nutty.model.PrivacyOptions.PrivacyOptions(long user_id, int followable, int visible_health_condition, int visible_food_intolerance, int visible_not_pref, int visible_activities)']]]
];
