var searchData=
[
  ['root',['root',['../bootbox_8js.html#a11a10a6834f3c54a5380f4ff04d002a9',1,'bootbox.js']]]
];
